# Railway V5 prospective registration candidate

Status: AUTHOR_REVIEW_REQUIRED, not an authorization or a completed formal qualification. This policy governs a proposed new run, never relabels previous observations, and must be approved before observing its responses.

## Research question and claim boundary

Can the implemented ATLAS generation, layered validation, finding-driven candidate/dependency compilation and non-regression repair policies transfer to the supplied MDE-near-domain railway configuration models? The study is a finite, author-designed case study. It is not operational railway safety validation, an independent external benchmark, arbitrary natural-language requirements understanding, or a demonstration across all MDE domains.

The candidate retains all 24 previously constructed bases: three task families crossed with eight layouts, with one shared template ancestor. Each base has one single-query fault and one compound fault (12 dependency-coupled witnesses and 12 concurrent faults overall). The six native queries each have four single-fault cases. These are coverage strata, not 24 independently sampled templates. Task-only/native-clean fault efficacy is not a separate main stratum; task obligations remain part of every final score. No stronger task-only repair claim is allowed.

All cases were available during development, construction and deterministic search qualification. Paid diagnostics also exposed related small and complex templates and repair patterns. The frozen development cohort is reused prospectively with NEW responses; it is not a blind holdout. No original paid result is inserted into the main analysis. Do not select, replace, enlarge, or stop the cohort based on formal arm advantage. A future independent-template study is distinct work, not silently appended evidence.

This 24-base size is selected for complete coverage of the existing family/layout crossing, not for guaranteed power or a +/-10 percentage-point population interval. Report exact finite-case estimates, paired scenario/layout resampling sensitivity, and the lack of template-level identification. The supplied hypothetical precision grid makes the limitation explicit. If the paper requires population-level superiority or a reliably detectable small gain, this candidate is insufficient and must not be approved under that stronger claim.

## Fixed allocation and shared inputs

G: 24 bases x 3 seeds = 72 shared generations, producing 216 G0/GS/GF outcome cells. Reuse the identical first generated artifact for GS and GF. Do not generate separate starting models. Keep the current core helper's GS-then-GF order and disclose the fixed branch-order limitation. G0 is a measured shared response, not a third generation call.

R: 48 damaged inputs x 3 seeds x S/V/F = 432 outcome cells. Within each triplet use the identical public task, input and seed. Cycle through all six arm permutations equally over the 144 triplets, then mix G and R triplets using a fixed scheduling RNG seed (20260908, not a model seed). This order is a prescribed runner requirement; a JSON schedule alone is not evidence of its execution.

CLEAN: three canonical chain-layout inputs (one per task family), three seeds, S/V/F = 27 SEPARATE descriptive cells. These are known-clean input models, not repair answers. Do not provide this clean-input directory to G/R prompt construction. Report field changes, preserved validity, system release and induced failures; do not call unchanged clean inputs automatic repair successes. Nine S endpoints allow at most 18 proposals; V/F must stop clean with zero calls after real validation. This is a three-input sentinel, not a clean-control estimate over all eight layouts.

Boundary: repeat the existing 39 scripted common-runner checks under the final formal release: clean, no permitted site, conflicting public requirements and missing native backend for all three families/arms, plus induced-error S probes. They are software controls, not model performance and not main or CLEAN observations. No extra paid boundary calls are proposed. A missing backend must actually be missing; a label must not supply an oracle outcome.

Max logical opportunities: G 72 x (1+2+2)=360; R 432 x 2=864; CLEAN S 9 x 2=18; total 1,242. This is an upper bound, not a target. Eight HTTP attempts per logical request imply an upper bound of 9,936 attempts before any separately authorized unknown recovery. New formal limits cannot reuse or enlarge the old development 18/144 permit. No payment is authorized by this document.

## Policy parity and collection

Use the exact PIL/AUTOSAR parameter reference bytes and the unchanged runtime parameter dictionary, including all three model seeds, temperature, reasoning effort, token cap, schema mode, identity checks, timeout and explicit transport settings. Model configuration is distinct from the two-opportunity/six-explicit-field repair policy. Provider-reported model identity is recorded, not independent third-party deployment certification.

S receives no executed findings and retains its last legal revision; no score-based best-of-k selection. V/F receive the same findings and use the same V20 non-regression acceptance; F adds candidate localization and dependency compilation. F-V estimates this bundle, not any one internal component. All arms use the same independently scored selected-artifact endpoint. Independent scores must not enter S prompts or selection. Repair loops need not consume all opportunities.

For each opportunity retain: exact prompt/schema and raw request/response bytes; provider model/response identity; logical and HTTP IDs; usage including unavailable fields; input model/XMI hashes; layered findings and source locators; candidate plan and dependency groups; explicit patch versus opposite-closure effects; actual changed fields; proposal/materialization/acceptance; new findings and coverage/frame changes; stop reason and system release; final selected model/XMI and a fresh independent native/task score. Counts refer separately to planned endpoints, proposal opportunities and physical HTTP attempts.

Record dependency groups generated, multi-field proposals received, multi-field proposals actually changing more than one explicit field, accepted transactions and final success SEPARATELY. A coupled construction witness does not prove every valid repair requires a joint transaction. Valid single-field alternatives remain valid. Do not force joint edits, count implicit inverse updates as explicit multi-field proposals, or attribute an S transaction to F.

## Outcomes, missingness and analysis

Primary strict artifact outcome: materializable and loadable selected XMI; metamodel structure valid; all six native queries executed and empty; all applicable task obligations and frame satisfied. Also report actual system RELEASE separately: blocking a bad artifact is protection, not automatic repair success. A BUDGET_EXHAUSTED label alone does not mean failure. Refusal, truncation and invalid proposals are observed response categories; final outcome follows the independently validated selected artifact, if present.

No artifact after a received failed generation is an observed generation failure, and both dependent branches retain the same failed starting point without replacement. Missing responses, incomplete native execution, hash/replay inconsistency or missing independent score are unresolved, not model failures. Halt dispatch and preserve evidence. The candidate retains the conservative existing transport policy: known retryable HTTP responses may retry identical wire content within eight attempts; ambiguous transport does not auto-reissue. Any unknown reissue needs a separate, input-identical, bounded recovery authorization with cross-run counters and possible duplicate billing disclosed. Already received responses must never be resampled. No success-dependent retry or deletion.

Keep all planned main cells in the denominator. Any unresolved cell suppresses the affected stage's main point estimate/resampling and produces all-planned worst/best bounds. A fully resolved predeclared descriptive subgroup can be displayed as such, not substituted for the primary endpoint.

Predeclared contrasts: R F-S primary; R F-V key secondary; G GF-GS and GF-G0 secondary. For R first average two mutations and three seeds within each base, then equally average bases; for G equally average seeds within base then bases. Preserve paired arms, mutations and seeds in resampling. Use the existing analysis code's four-comparison nominal family allocation (alpha .05, marginal .9875), 9,999 resamples, RNG 8675309. These are empirical sensitivity intervals, not calibrated railway-population confidence guarantees; no p-values. A single ancestor cannot produce a template interval. Degenerate empirical distributions are not evidence of certainty.

Report single/coupled/concurrent, task-family and layout subgroups descriptively without additional significance tests, plus 0/3 through 3/3 seed stability and unresolved counts. Report paired improvement and deterioration, actual calls/tokens/latency, unknown usage, initial failures and repair reachability. Natural G repair gain is evaluated among the prespecified actually failing shared starts, alongside the ALL-start G contrast; if none fail, natural repair gain is not estimable, and G must not be expanded until failures appear.

Replay the same ACTUALLY proposed candidate offline through acceptance diagnostics where applicable. This diagnoses protection on observed candidates only, not an alternative multi-round trajectory or an independent trial. Strong deterministic public-input search results must remain visible, with both predeclared traversal orders, finite candidate/time limits and unknowns; no per-case best-order mixing. Existing D0 results retain their development and environment identity, and are not a contemporaneous formal timing comparison.

## Evidence-to-paper decisions fixed in advance

If F improves over S but not V: support the validation-guided policy, not incremental localization/dependency efficacy. If F improves over both with coherent strata: support the full policy and the additional localization/dependency bundle WITHIN this finite case set, not atomic-transaction necessity or universal superiority. If all arms tie near the ceiling: the implementation transfer is evidenced, incremental repair effectiveness is inconclusive. If F loses: report the loss and failure traces; do not rewrite it as an efficacy win. If a mechanism is never exercised: report software/path evidence only, not measured mechanism benefit.

The paper's methods, results, limitations and reviewer reply must use the same distinctions. Existing BESSER constructive-mapping evidence remains limited and unchanged; it is not a substitute for the actual ATLAS XMI/EMF validation/repair chain. This registration cannot ensure positive results; it aims to make positive, null and negative results auditable and interpretable.

## Before any new paid run

1. Project author approves this exact cohort/controls, finite-study claim scope and analysis/transport policy. Reviewer is recorded as 项目作者 only after actual approval, never by the assembler.
2. Implement and qualify a formal-only scheduler/admission/export boundary, binding this manifest, all public inputs, execution order, budgets and environment. Do not loosen the existing development-only gate or relabel its outcomes.
3. Run fresh final-version full regression, all exact initial requests/schema/parity checks, 39 real offline boundary checks, full schedule offline dispatch/export/accounting tests and independent artifact replay. Verify stop/resume/recovery and negative tamper tests before touching credentials. Recheck original source and historical evidence seals.
4. Freeze the actual qualified source/environment package and retain an external digest. Obtain explicit paid and third-party data-transfer authorization for that release and scope. Only then dispatch. Any later material code/input/policy change requires a new release, not editing a running experiment.
