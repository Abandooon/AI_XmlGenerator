"""Build a self-hashed inventory for the complete V6.3.4 paper-evidence root."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
from typing import Any


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(value)).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_self_hashed(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    body = {key: item for key, item in value.items() if key != "content_sha256"}
    if value.get("content_sha256") != canonical_sha256(body):
        raise RuntimeError(f"content_hash_mismatch:{path}")
    return value


def atomic_write_json(path: Path, value: dict[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--bundle-archive", type=Path, required=True)
    parser.add_argument("--qualification-archive", type=Path, required=True)
    parser.add_argument("--formal-archive", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output.resolve()

    formal_result = load_self_hashed(root / "FORMAL_RESULT.json")
    formal_recompute = load_self_hashed(root / "FORMAL_RESULT_RECOMPUTE.json")
    paper_analysis = load_self_hashed(root / "PAPER_ANALYSIS.json")
    paper_recompute = load_self_hashed(root / "PAPER_ANALYSIS_RECOMPUTE.json")
    if formal_result != formal_recompute:
        raise RuntimeError("formal_recomputation_not_byte_equivalent")
    if paper_analysis != paper_recompute:
        raise RuntimeError("paper_analysis_recomputation_not_byte_equivalent")
    if formal_result.get("decision") != "PASS" or not formal_result.get(
        "paper_result_admissible"
    ):
        raise RuntimeError("formal_result_not_admissible")
    if paper_analysis.get("decision") != "PASS":
        raise RuntimeError("paper_analysis_not_pass")

    excluded = {
        output,
        output.with_suffix(output.suffix + ".tmp"),
    }
    records: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path in excluded or "__pycache__" in path.parts:
            continue
        records.append(
            {
                "path": path.relative_to(root).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )

    source_archives = []
    for label, path in (
        ("bundle", args.bundle_archive.resolve()),
        ("qualification_evidence", args.qualification_archive.resolve()),
        ("raw_formal_evidence", args.formal_archive.resolve()),
    ):
        source_archives.append(
            {
                "label": label,
                "file_name": path.name,
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )

    manifest: dict[str, Any] = {
        "schema_version": "atlas.vllm.uga.paper_evidence_manifest.v1",
        "decision": "PASS",
        "experiment_id": "atlas-vllm-uga-qwen35-formal-v6-3-4",
        "record_count": len(records),
        "records": records,
        "source_archives": source_archives,
        "formal_result_content_sha256": formal_result["content_sha256"],
        "paper_analysis_content_sha256": paper_analysis["content_sha256"],
        "formal_recomputation_byte_identical": True,
        "paper_analysis_recomputation_byte_identical": True,
        "builder_file_sha256": sha256_file(Path(__file__).resolve()),
    }
    manifest["content_sha256"] = canonical_sha256(manifest)
    atomic_write_json(output, manifest)
    print(
        json.dumps(
            {
                "decision": manifest["decision"],
                "record_count": manifest["record_count"],
                "content_sha256": manifest["content_sha256"],
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
