# ATLAS V6.3.4 正式 180 请求实验结果与论文使用边界

日期：2026-08-29（Asia/Shanghai）  
用途：SoSyM `SOSYM-26-00005681` 修订、审稿回复、证据发布与下一窗口交接。本文不修改论文工作稿或权威原稿。

## 1. 最终结论

ATLAS 本地 vLLM U/G/A V6.3.4 正式实验完成，并通过独立验证与第二次只读复算：

- 20 cases × 3 repetitions × U/G/A = **180 个且仅 180 个完整请求**；
- 完整正式 root 为 `formal_run_b1`，无 retry、无基础设施失败，`RUN_MANIFEST=COMPLETE`；
- 180 个结果、180 个后处理报告、运行账本和 60 个 A 臂审计请求全部通过哈希与身份复核；
- G、A 均为 **60/60** JSON Schema、物化、XSD、selection obligation、独立评价和端到端结构 PASS；
- U 为 **45/60** 端到端结构 PASS；15 个失败集中在 5/20 cases，且每个 case 的三次重复产生完全相同的失败输出；
- 60/60 个 G/A 配对输出字节相同、token hash 相同、全部在线及离线裁决相同；
- A 臂 Grammar 在 54,942 个可观测 token steps 中实际约束了 516 步，binding rate 为 **0.9392%**；
- 第一次独立正式验证与第二次只读复算输出逐字节相同；论文统计也逐字节复算一致。

本结果可以作为一个**独立的、同模型同运行时的 finite instance-contract enforcement 机制研究**。它不能替代 V17 primary，不能与 Luna 做模型排名，也不能证明通用 AUTOSAR 语义生成或完整合规。

## 2. 为什么 V6.1.1 不再作为论文结果

V6.1.1 虽然完成过 180 请求，但后续审查发现其 execution-schema 编译器没有完整保留冻结实例的值约束和必需属性约束。因此当时 G/A 的 JSON Schema 60/60 只说明模型满足了一个过弱的转换后结构；XSD 仅 42/60、端到端仅 18/60，不能回答预期的“完整冻结实例契约是否可被受控解码强制执行”。V6.1.1 应保留为 rejected diagnostic，不应继续引用其 `579/55,020` 或 30%/70% 等数字支撑论文。

V6.3.4 不是对旧结果的重标，而是新的处理身份和新的完整运行。其编译器把冻结 source snapshot 的 720 个实例约束全部转换为可执行约束：

- 670 个非数值 exact constraints 使用 `const`；
- 50 个数值 exact constraints 使用相等的 `minimum`/`maximum`，规避 XGrammar 0.2.6rc1 的 numeric-`const` 缺陷；
- 754 个 exact-value mutation negatives 与 1,451 个 required-property deletion negatives 全部被拒绝；
- 20/20 case witnesses 经 JSON Schema、XGrammar、物化、XSD、selection obligations 和独立 evaluator 验证通过；
- 所有数组都具有有限且正向的 cardinality bounds。

这意味着实验处理是**实例特定的最终 IR 合同**，不是泛化的 AUTOSAR XSD，也不是运行时 Neo4j 动态拼接。该设计适合回答“Grammar 能否执行预先编译的完整合同、何时实际 binding、审计是否非干扰”；不适合回答“模型能否自行推断完整 AUTOSAR 语义”。

## 3. 三臂、Prompt、Schema 与执行边界

- 模型：冻结的 Qwen3.5-9B 模型树；
- 运行时：vLLM 0.26.0、XGrammar 0.2.6rc1、2 × RTX 4090 tensor parallel；
- Prompt：20 份冻结英文 requirement 与英文 active output contract；
- Schema：由冻结历史 source schema snapshot 离线、确定性地编译为 case-specific finite JSON Schema Draft 2020-12；
- 运行时不访问 Neo4j，不动态决定或拼接 schema；
- U：不启用 grammar、不启用 audit；
- G：启用 JSON Schema → XGrammar；
- A：使用与 G 完全相同的 schema/grammar，并额外启用 fail-closed token audit；
- 本实验没有 GBNF arm，也不是 JSON Schema 与 GBNF 的比较；
- G/A 以同一 execution-schema bytes 执行 prompt、XGrammar 与 posterior validation。

## 4. 零模型门禁与资格实验

全新 a13 root 在发出模型请求前完成并通过：

- 双卡 CUDA/Torch 与 NCCL two-rank gate；
- runtime fingerprint；
- 20 个 schema 编译与 20 个当前 witness 回归；
- 冻结 V4 standard/full token sequence 在原始 schema snapshot 上分别于 token index 599/1214 被拒绝；
- structured-stop detokenization regression；
- 9-request qualification schedule/contract 与 dry-run，dry-run external calls = 0。

资格实验 9/9 请求完成。U 是观察性 baseline，允许失败；G/A 三个 block 均完全通过且逐字节一致。独立 qualification verifier 为 `PASS`，A 臂 binding 为 `25/2,905 = 0.8606%`。qualification 仅是 formal admission gate，其成功率和 binding 不进入论文正式结果。

## 5. 正式结果

### 5.1 分臂结果（每臂 n=60）

| 指标 | U | G | A |
|---|---:|---:|---:|
| JSON parse PASS | 60/60 (100%) | 60/60 (100%) | 60/60 (100%) |
| single JSON value PASS | 60/60 (100%) | 60/60 (100%) | 60/60 (100%) |
| execution JSON Schema PASS | 45/60 (75%) | 60/60 (100%) | 60/60 (100%) |
| termination COMPLETE | 60/60 (100%) | 60/60 (100%) | 60/60 (100%) |
| materialization PASS | 45/60 (75%) | 60/60 (100%) | 60/60 (100%) |
| XSD PASS | 45/60 (75%) | 60/60 (100%) | 60/60 (100%) |
| selection obligation PASS | 45/60 (75%) | 60/60 (100%) | 60/60 (100%) |
| independent evaluator PASS | 45/60 (75%) | 60/60 (100%) | 60/60 (100%) |
| end-to-end structural PASS | 45/60 (75%) | 60/60 (100%) | 60/60 (100%) |
| mean completion tokens | 1,227.4 | 915.7 | 915.7 |
| mean request elapsed seconds | 13.525 | 10.365 | 13.252 |

请求级端到端通过率的描述性 Wilson 95% intervals 为：U 62.77%--84.22%，G/A 93.98%--100%。这些区间把 60 次重复作为运行级描述，不能取代 case-level 推断。

### 5.2 预声明的 U vs G 主终点

独立统计单位是 case。对每个 case 比较三次 U 与三次 G 的端到端 PASS 数：

- G improved：5 cases；
- G worsened：0 cases；
- ties：15 cases；
- ties discarded 的双侧 exact sign test：**p = 0.0625**。

因此，正确的论文表述是：

> 在该冻结 20-case benchmark 中，受控解码的方向性结果为 5 个 case 改善、0 个恶化，但预声明的双侧 case-level 检验未越过 0.05 阈值（p=0.0625）。作为描述性运行级结果，端到端通过率由 45/60（75%）提高到 60/60（100%），绝对差 25 percentage points。

不得把 15 个失败运行视为 15 个独立 case 并报告 run-level McNemar `p=6.10e-5`；同一 case 内三次重复是聚类观测。

### 5.3 分层描述

| Tier | U end-to-end | G end-to-end | A end-to-end |
|---|---:|---:|---:|
| Minimal | 9/18 | 18/18 | 18/18 |
| Standard | 18/21 | 21/21 | 21/21 |
| Full | 18/21 | 21/21 | 21/21 |

分层单元较小、非随机且未做 multiplicity adjustment，只应描述，不应追加分层显著性主张。

### 5.4 U 臂失败的可复现机制

15 个失败恰好来自 5 个 cases，每个 case 三次重复均失败且 output SHA-256 相同：

- `ASW-MIN-04/05/06`：把应为 array 的 `NONQUEUED-RECEIVER-COM-SPEC` 生成成 object；每次一个 `type` error；
- `ASW-STD-06`：稳定产生错误的 variable-access nesting，代表性输出有 14 个 `required`/`additionalProperties` errors；
- `ASW-FULL-04`：同类 `AUTOSAR-VARIABLE-IREF` 与 `TARGET-DATA-PROTOTYPE-REF` nesting 错误，代表性输出有 16 个 `required`/`additionalProperties` errors。

因此 75%→100% 不是 parse 修复，也不是偶发重试收益；它来自 grammar 对冻结实例合同中数组类型、嵌套位置、必需字段和 exact values 的执行。

### 5.5 G vs A 非干扰、binding 与开销

- 60/60 paired output bytes 和 output token hashes 相同；
- 60/60 completion token counts 相同；
- 60/60 在线 parse/schema/termination 与离线所有裁决相同；
- 60 个 A request 的 external→internal identity、start/end、sequence、hash chain、token evidence 和 grammar termination 全部验证通过；
- evaluable steps = 54,942；steps bound = 516；binding rate = **0.9392%**。

Binding 的含义是：在这些 token steps 上，grammar 排除了未约束分布原本会允许的至少一个候选，并改变了 pre-mask argmax 可行性。它是**机制证据**，不是成功率、正确率或“1% token 被改写”的同义词。

同输出配对下的 A 相对 G 开销：

- A−G elapsed mean `+2.887 s`；median `+2.634 s`；nearest-rank p95 `+5.897 s`；
- A/G elapsed ratio median `1.279`；nearest-rank p95 `1.301`；
- 两臂 elapsed sums 之比 `1.2785`，即本次顺序云运行中约 **27.85%** 的观测审计开销。

该数字是当前硬件和顺序运行的 matched instrumentation overhead，不是硬件无关吞吐率。

## 6. 对审稿意见的直接支持

本结果可支持 Reviewer 1 的以下回应：

1. **R1-01（已知技术与新颖性）**：不主张发明 JSON Schema、XGrammar 或 constrained decoding；贡献限定为责任分离、冻结合同、fail-closed 证据链和独立复核。
2. **R1-03（跨模型比较无效）**：U/G/A 使用同一 Qwen3.5-9B、同 prompt、同 case、同 seed/sampling、同 runtime；机制比较不依赖 Qwen/Luna 横向排名。
3. **R1-06（hosted structured output 与 token masking 混淆）**：V17 仍称 provider schema-bounded generation；V6.3.4 单独称本地 XGrammar token-level mechanism study。
4. **R1-07（旧 allowed-token 指标不可复核）**：不用旧 `156 allowed tokens`；改用 60 条闭合 audit chains 和 516/54,942 的明确 pre-mask binding 定义。
5. **R1-08（audit 效用）**：只能主张 traceability、非干扰和观测开销，不能主张优于 IDE、提高工程师生产率或人类效用。

本结果仍不能支持：

- 完整 AUTOSAR 语义正确性、认证或系统级合规；
- 动态 Neo4j schema selection 的正确性；本实验没有该处理；
- JSON Schema 与 GBNF 的优劣；本实验没有 GBNF arm；
- Qwen 与 Luna 的模型优劣；
- 跨域泛化；
- `p<0.05` 的 confirmatory efficacy claim；case-level p=0.0625；
- 由 100% G/A 反推模型独立完成了语义推理，因为 finite execution schema 已编码完整实例合同。

## 7. 身份链与本地材料

### 7.1 关键 SHA-256

| 对象 | SHA-256 / content SHA-256 |
|---|---|
| V6.3.4 bundle archive | `ff87d1cda488b8a0aecaf6b36f0f9c243ad1504772d59500a581f7cbf78fe0dd` |
| bundle manifest content | `2286c25d9162fccdecae25ea06869dace6eb2001f232563b1f53c58c3e0517f6` |
| qualification evidence archive | `ac73d67d06c31bc3917e6a5e2b0c095a5665b4e715c67b4ba7eb08210bd69326` |
| qualification result content | `c97cef520281bf589eab70921254a64fe024bd662674cf7712a471d349463a1d` |
| formal schedule content | `40cee7869129fb330b5e6ad0983ff254453f4262e64c6c676b37ef8b9c3f3d7f` |
| formal contract content | `38cc85b4624dff79b5e7cae9f0fc0b0352e001ac6eb7290311b9187da63c0ffd` |
| formal run manifest content | `e6d9f4c687f6d171f0770d33358b8bf46b221dba8118a726b9aed595972cf133` |
| formal run ledger file | `7eac9fd3161a6639624a67f774180364c1ca1e661697b72c446c3878b2655361` |
| formal run ledger final chain | `bd51c98b4fe21448ccb0067ab45d4384c24d945ea18f036e065e6e62fb98b874` |
| postprocess manifest content | `f78c70f75f2045764590f3b31655a35ffaa45e99023f1791339d95b45c53f57e` |
| formal verifier file | `82cdf47ffbb6c3f99959d922020f1b6805813172e112bef480bf5c83db6248ad` |
| formal result content | `f97aa7d4fc75a9ecb8498136abb56f87ffd975acae0c123acab14aaf4245f02c` |
| formal result file | `38baace5fbcdec0da40db120f7318815daf02afd3ab1a055c4338e325cac527d` |
| paper analysis content | `3deb4af8a8357047d92f555cd692cbd6271bab2c62ed7655ea4738c18c27f6a7` |
| raw formal evidence archive | `2e10f10d19133c8ede0b69145a6a31098979eeff6f2898df353a5fd7a856db83` |

`PAPER_ANALYSIS.json` 在本说明生成前最后一次重算的 content hash 如上；若分析脚本或 JSON 后续有任何合法修订，应以新文件自带 hash 和最终 paper-evidence archive manifest 为准。

### 7.2 路径

- 冻结 bundle：`E:\54239\Documents\atlas_vllm_uga_qwen35_deploy_v6_2_0_2026-08-28\bundle`
- bundle archive：`E:\54239\Documents\atlas-vllm-uga-v6-3-4-bundle-20260829.tar.gz`
- qualification evidence：`E:\54239\Documents\atlas_vllm_uga_v6_3_4_qualification_evidence_2026-08-29\atlas-vllm-uga-v6-3-4-run-2286c25d-a13`
- formal evidence root：`E:\54239\Documents\atlas_vllm_uga_v6_3_4_formal_b1_evidence_2026-08-29`
- raw formal evidence archive：`E:\54239\Documents\atlas-vllm-uga-v6-3-4-run-2286c25d-a13-formal-b1-evidence.tar.gz`
- independent formal result：formal evidence root 下 `FORMAL_RESULT.json`
- second read-only recomputation：formal evidence root 下 `FORMAL_RESULT_RECOMPUTE.json`
- paper analysis：formal evidence root 下 `PAPER_ANALYSIS.json`
- analysis recomputation：formal evidence root 下 `PAPER_ANALYSIS_RECOMPUTE.json`
- formal verifier：formal evidence root 下 `verify_uga_formal_v032.py`
- paper analysis script：formal evidence root 下 `analyze_formal_results_v1.py`

## 8. 运行异常与排除记录

- V6.2–V6.3.3 的 a7–a12 roots 均在零模型 gate 失败，模型请求为 0，保留为诊断证据；
- `formal_run` 在 140/180 时因桌面关闭前台 SSH 会话而被外部中断，没有模型/schema failure；该 partial root 冻结且不进入结果；
- `formal_run_b1` 使用同一冻结 schedule/contract 从头执行 180/180，是唯一纳入正式结果的 root；
- formal verifier 是 post-run 独立分析工具，不属于冻结 treatment bundle。它固定并检查 qualification identity、formal contract/schedule、180 个结果、账本、180 个后处理报告、60 个 G/A 配对和 60 条 A audit chains；其文件 hash 写入正式结果，并已第二次只读复算出逐字节相同结果。

## 9. 论文整合状态

论文工作稿目前**未修改**。建议先审核随证据提供的独立 LaTeX 草稿，再决定是否合入 `ATLAS_evaluation_v17.tex`。整合时必须：

1. 将本研究标为 local same-model mechanism study，与 V17 primary 分节，不做绝对率排名；
2. 明示 720 个 exact instance constraints 与 instance-specific contract 边界；
3. 同时报告 U/G/A 全门禁表，不能只报 100% XSD；
4. 主检验报告 case-level `5/0/15, p=0.0625`，请求级 75%→100% 仅作描述；
5. binding 与成功率分开；
6. 同时报告 G/A 非干扰和约 27.85% 审计开销；
7. 明示 V6.1.1 rejected diagnostic，避免两个互相冲突的正式数字并存。

## 10. 云实例状态

正式 runner、metrics monitor 与 vLLM server 已停止，证据已经下载并完成本地哈希复核。云实例本身仍按用户此前要求保持开启；从本实验数据安全与继续复算角度，已经可以关闭。

