"""Derive paper-facing descriptive and paired statistics from verified V6.3.4 evidence."""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
from statistics import mean, median
from typing import Any

from jsonschema import Draft202012Validator


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(value)).hexdigest()


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_self_hashed(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    claimed = value.get("content_sha256")
    body = {key: item for key, item in value.items() if key != "content_sha256"}
    if claimed != canonical_sha256(body):
        raise RuntimeError(f"content_hash_mismatch:{path}")
    return value


def percentile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    if not ordered:
        raise ValueError("empty_values")
    position = (len(ordered) - 1) * probability
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    fraction = position - lower
    return ordered[lower] * (1.0 - fraction) + ordered[upper] * fraction


def percentile_nearest_rank(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    if not ordered:
        raise ValueError("empty_values")
    return ordered[max(0, math.ceil(probability * len(ordered)) - 1)]


def wilson_interval(successes: int, trials: int, z: float = 1.959963984540054) -> list[float]:
    proportion = successes / trials
    denominator = 1.0 + z * z / trials
    center = (proportion + z * z / (2.0 * trials)) / denominator
    margin = (
        z
        * math.sqrt(
            proportion * (1.0 - proportion) / trials
            + z * z / (4.0 * trials * trials)
        )
        / denominator
    )
    return [center - margin, center + margin]


def exact_sign_two_sided(improved: int, worsened: int) -> float:
    non_ties = improved + worsened
    if non_ties == 0:
        return 1.0
    tail = sum(math.comb(non_ties, k) for k in range(0, min(improved, worsened) + 1))
    return min(1.0, 2.0 * tail / (2**non_ties))


def summarize_numeric(values: list[float]) -> dict[str, float]:
    return {
        "sum": sum(values),
        "mean": mean(values),
        "median": median(values),
        "p95_linear": percentile(values, 0.95),
        "p95_nearest_rank": percentile_nearest_rank(values, 0.95),
        "min": min(values),
        "max": max(values),
    }


def compact_value(value: Any) -> Any:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True)[:500]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()

    formal_result_path = root / "FORMAL_RESULT.json"
    formal_result = load_self_hashed(formal_result_path)
    if formal_result.get("decision") != "PASS" or not formal_result.get(
        "paper_result_admissible"
    ):
        raise RuntimeError("formal_result_not_admissible")

    schedule = load_self_hashed(root / "FORMAL_SCHEDULE.json")
    result_by_request: dict[str, dict[str, Any]] = {}
    for path in sorted((root / "formal_run_b1").glob("[0-9][0-9][0-9].json")):
        result = load_self_hashed(path)
        result_by_request[result["schedule"]["request_id"]] = result
    if len(result_by_request) != 180:
        raise RuntimeError("unexpected_result_count")

    schedule_by_request = {
        record["request_id"]: record for record in schedule["records"]
    }
    postprocess_by_request: dict[str, dict[str, Any]] = {}
    for path in sorted(
        (root / "formal_postprocess_local_v1").glob("[0-9][0-9][0-9].json")
    ):
        report = load_self_hashed(path)
        postprocess_by_request[report["request_id"]] = report
    if len(postprocess_by_request) != 180:
        raise RuntimeError("unexpected_postprocess_count")

    failed_u_by_case: dict[str, list[dict[str, Any]]] = {}
    for record in schedule["records"]:
        if record["arm"] != "U":
            continue
        result = result_by_request[record["request_id"]]
        if result["schema_decision"] == "PASS":
            continue
        asset = load_self_hashed(root / "compiled_assets" / "cases" / f"{record['case_id']}.json")
        instance = json.loads(result["output"])
        errors = sorted(
            Draft202012Validator(asset["schema"]).iter_errors(instance),
            key=lambda item: (list(item.absolute_path), list(item.absolute_schema_path)),
        )
        if len(errors) != int(result["schema_error_count"]):
            raise RuntimeError(f"schema_error_reproduction_mismatch:{record['request_id']}")
        failed_u_by_case.setdefault(record["case_id"], []).append(
            {
                "repetition": record["repetition"],
                "output_sha256": result["output_sha256"],
                "error_count": len(errors),
                "errors": [
                    {
                        "validator": error.validator,
                        "instance_path": "/" + "/".join(map(str, error.absolute_path)),
                        "schema_path": "/" + "/".join(map(str, error.absolute_schema_path)),
                        "observed": compact_value(error.instance),
                        "expected": compact_value(error.validator_value),
                        "message": error.message,
                    }
                    for error in errors
                ],
            }
        )

    u_failure_case_diagnostics: dict[str, Any] = {}
    for case_id, records in sorted(failed_u_by_case.items()):
        representative = records[0]
        validators = Counter(
            error["validator"] for error in representative["errors"]
        )
        u_failure_case_diagnostics[case_id] = {
            "failed_repeat_count": len(records),
            "repetitions": [record["repetition"] for record in records],
            "unique_output_sha256_count": len(
                {record["output_sha256"] for record in records}
            ),
            "representative_error_count": representative["error_count"],
            "representative_validator_counts": dict(sorted(validators.items())),
            "representative_errors": representative["errors"],
        }
    arm_statistics: dict[str, dict[str, Any]] = {}
    for arm in ("U", "G", "A"):
        ids = [
            record["request_id"]
            for record in schedule["records"]
            if record["arm"] == arm
        ]
        elapsed = [float(result_by_request[item]["elapsed_seconds"]) for item in ids]
        completion = [
            float(result_by_request[item]["usage"]["completion_tokens"])
            for item in ids
        ]
        passes = int(
            formal_result["arm_summary"][arm][
                "end_to_end_structural_decision_pass_count"
            ]
        )
        arm_statistics[arm] = {
            "request_count": len(ids),
            "end_to_end_pass_count": passes,
            "end_to_end_pass_rate": passes / len(ids),
            "end_to_end_pass_rate_wilson_95": wilson_interval(passes, len(ids)),
            "elapsed_seconds": summarize_numeric(elapsed),
            "completion_tokens": summarize_numeric(completion),
        }

    by_block: dict[int, dict[str, str]] = {}
    for record in schedule["records"]:
        by_block.setdefault(int(record["block_ordinal"]), {})[record["arm"]] = record[
            "request_id"
        ]
    ga_elapsed_deltas: list[float] = []
    ga_elapsed_ratios: list[float] = []
    ga_token_deltas: list[float] = []
    for block in by_block.values():
        g = result_by_request[block["G"]]
        a = result_by_request[block["A"]]
        g_elapsed = float(g["elapsed_seconds"])
        a_elapsed = float(a["elapsed_seconds"])
        ga_elapsed_deltas.append(a_elapsed - g_elapsed)
        ga_elapsed_ratios.append(a_elapsed / g_elapsed)
        ga_token_deltas.append(
            float(a["usage"]["completion_tokens"])
            - float(g["usage"]["completion_tokens"])
        )

    paired = formal_result["paired_end_to_end"]
    case_comparisons: list[dict[str, Any]] = []
    for case_id in sorted({record["case_id"] for record in schedule["records"]}):
        pass_counts: dict[str, int] = {}
        case_records = [
            record for record in schedule["records"] if record["case_id"] == case_id
        ]
        for arm in ("U", "G", "A"):
            pass_counts[arm] = sum(
                postprocess_by_request[record["request_id"]].get(
                    "end_to_end_structural_decision"
                )
                == "PASS"
                for record in case_records
                if record["arm"] == arm
            )
        direction = (
            "G_IMPROVED"
            if pass_counts["G"] > pass_counts["U"]
            else "G_WORSENED"
            if pass_counts["G"] < pass_counts["U"]
            else "TIE"
        )
        case_comparisons.append(
            {
                "case_id": case_id,
                "tier": case_records[0]["tier"],
                "u_pass_count_of_3": pass_counts["U"],
                "g_pass_count_of_3": pass_counts["G"],
                "a_pass_count_of_3": pass_counts["A"],
                "u_vs_g_direction": direction,
            }
        )
    improved_cases = sum(
        item["u_vs_g_direction"] == "G_IMPROVED" for item in case_comparisons
    )
    worsened_cases = sum(
        item["u_vs_g_direction"] == "G_WORSENED" for item in case_comparisons
    )
    tied_cases = sum(item["u_vs_g_direction"] == "TIE" for item in case_comparisons)

    binding = formal_result["audit_verification"]["binding"]
    output: dict[str, Any] = {
        "schema_version": "atlas.vllm.uga.paper_analysis.v1",
        "decision": "PASS",
        "scope": (
            "Frozen 20-case, 3-tier, 3-repeat benchmark under the qualified "
            "Qwen3.5-9B/vLLM runtime; not a claim of general AUTOSAR semantic correctness."
        ),
        "formal_result_file_sha256": sha256_file(formal_result_path),
        "formal_result_content_sha256": formal_result["content_sha256"],
        "formal_schedule_content_sha256": schedule["content_sha256"],
        "arm_statistics": arm_statistics,
        "primary_case_level_efficacy": {
            "comparison": "U_vs_G_end_to_end_structural_pass_count_across_three_repetitions",
            "independent_unit": "case",
            "case_count": len(case_comparisons),
            "g_improved_case_count": improved_cases,
            "g_worsened_case_count": worsened_cases,
            "tied_case_count": tied_cases,
            "exact_two_sided_sign_test_p_ties_discarded": exact_sign_two_sided(
                improved_cases, worsened_cases
            ),
            "case_comparisons": case_comparisons,
        },
        "descriptive_request_level_efficacy": {
            "request_level_absolute_pass_rate_improvement": (
                arm_statistics["G"]["end_to_end_pass_rate"]
                - arm_statistics["U"]["end_to_end_pass_rate"]
            ),
            "u_fail_g_pass": int(paired["u_fail_g_pass"]),
            "u_pass_g_fail": int(paired["u_pass_g_fail"]),
            "inference": (
                "descriptive_only; repetitions are clustered within cases and must not "
                "be treated as 60 independent observations"
            ),
        },
        "tier_descriptive_results": formal_result["tier_arm_summary"],
        "u_failure_reproducibility": {
            "failed_request_count": sum(
                item["failed_repeat_count"]
                for item in u_failure_case_diagnostics.values()
            ),
            "failed_case_count": len(u_failure_case_diagnostics),
            "all_failed_cases_reproduced_in_all_three_repeats": all(
                item["failed_repeat_count"] == 3
                for item in u_failure_case_diagnostics.values()
            ),
            "all_failed_cases_deterministic_across_repeats": all(
                item["unique_output_sha256_count"] == 1
                for item in u_failure_case_diagnostics.values()
            ),
            "case_diagnostics": u_failure_case_diagnostics,
        },
        "audit_noninterference": {
            "ga_exact_output_match_count": len(formal_result["ga_equivalence"]),
            "ga_exact_output_match_total": len(formal_result["ga_equivalence"]),
            "ga_completion_token_delta": summarize_numeric(ga_token_deltas),
        },
        "audit_binding_mechanism": {
            "steps_bound": int(binding["steps_bound"]),
            "steps_observed": int(binding["steps_observed"]),
            "binding_rate": float(binding["binding_rate"]),
            "interpretation": (
                "Mechanism evidence: at these token steps the grammar excluded at least "
                "one token that the unconstrained model distribution would otherwise admit; "
                "this is not an efficacy rate."
            ),
        },
        "ga_matched_instrumentation_overhead": {
            "elapsed_seconds_delta_a_minus_g": summarize_numeric(ga_elapsed_deltas),
            "elapsed_ratio_a_over_g": summarize_numeric(ga_elapsed_ratios),
            "aggregate_elapsed_ratio_a_over_g": (
                arm_statistics["A"]["elapsed_seconds"]["sum"]
                / arm_statistics["G"]["elapsed_seconds"]["sum"]
            ),
            "aggregate_elapsed_overhead_fraction": (
                arm_statistics["A"]["elapsed_seconds"]["sum"]
                / arm_statistics["G"]["elapsed_seconds"]["sum"]
                - 1.0
            ),
            "caveat": (
                "Observed matched run-time overhead in this sequential cloud run; "
                "not a hardware-independent throughput estimate."
            ),
        },
    }
    output["analysis_script_file_sha256"] = sha256_file(Path(__file__))
    output["content_sha256"] = canonical_sha256(output)
    args.output.resolve().write_text(
        json.dumps(output, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "decision": output["decision"],
        "content_sha256": output["content_sha256"],
        "primary": output["primary_case_level_efficacy"],
        "binding": output["audit_binding_mechanism"],
        "overhead": output["ga_matched_instrumentation_overhead"],
    }, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
