"""Verify every registered file inside a V6.3.4 paper-evidence tar archive."""

from __future__ import annotations

import argparse
import hashlib
import json
import tarfile
from pathlib import PurePosixPath
from typing import Any


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(value)).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", required=True)
    args = parser.parse_args()

    with tarfile.open(args.archive, "r:gz") as archive:
        file_members = {
            PurePosixPath(member.name): member
            for member in archive.getmembers()
            if member.isfile()
        }
        manifest_candidates = [
            path for path in file_members if path.name == "PAPER_EVIDENCE_MANIFEST.json"
        ]
        if len(manifest_candidates) != 1:
            raise RuntimeError("paper_evidence_manifest_count_mismatch")
        manifest_path = manifest_candidates[0]
        prefix = manifest_path.parent
        manifest_handle = archive.extractfile(file_members[manifest_path])
        if manifest_handle is None:
            raise RuntimeError("paper_evidence_manifest_unreadable")
        manifest_bytes = manifest_handle.read()
        manifest = json.loads(manifest_bytes.decode("utf-8"))
        body = {
            key: item for key, item in manifest.items() if key != "content_sha256"
        }
        if manifest.get("content_sha256") != canonical_sha256(body):
            raise RuntimeError("paper_evidence_manifest_content_hash_mismatch")
        if manifest.get("decision") != "PASS":
            raise RuntimeError("paper_evidence_manifest_not_pass")

        expected_paths = {prefix / record["path"] for record in manifest["records"]}
        expected_paths.add(manifest_path)
        if set(file_members) != expected_paths:
            missing = sorted(map(str, expected_paths - set(file_members)))
            unexpected = sorted(map(str, set(file_members) - expected_paths))
            raise RuntimeError(
                f"archive_file_set_mismatch:missing={missing}:unexpected={unexpected}"
            )
        for record in manifest["records"]:
            member_path = prefix / record["path"]
            member = file_members[member_path]
            if member.size != int(record["bytes"]):
                raise RuntimeError(f"archive_size_mismatch:{record['path']}")
            handle = archive.extractfile(member)
            if handle is None:
                raise RuntimeError(f"archive_member_unreadable:{record['path']}")
            digest = hashlib.sha256()
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
            if digest.hexdigest() != record["sha256"]:
                raise RuntimeError(f"archive_hash_mismatch:{record['path']}")

    print(
        json.dumps(
            {
                "decision": "PASS",
                "registered_file_count": manifest["record_count"],
                "archive_file_count": len(file_members),
                "manifest_content_sha256": manifest["content_sha256"],
                "manifest_file_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
