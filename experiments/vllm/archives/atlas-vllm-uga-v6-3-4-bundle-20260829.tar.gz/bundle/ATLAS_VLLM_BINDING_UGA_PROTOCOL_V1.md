# ATLAS vLLM Binding and U/G/A Protocol V1

Date: 2026-08-27 (Asia/Shanghai)

Status: implementation qualification; no paper run has started.

## 1. Evidential role

This is an independent same-model mechanism microbenchmark. It does not replace,
pool with, or numerically compare against the frozen V17 Luna result. Its claims
are limited to:

1. whether XGrammar changes structural outcomes for a pinned local model;
2. whether the grammar actually rejects the model's pre-mask first choice at
   observable decoding steps; and
3. the overhead and output non-interference of fail-closed audit collection.

It does not establish algorithmic novelty, cross-domain generality, semantic
correctness from grammar compliance, human productivity, or superiority over an
IDE.

## 2. AUTOSAR inputs

Use the same 20 internally authored English V3 primary requirements as V17:

- source: `E:\54239\Documents\atlas_autosar_requirements_v3\asw_cases_v3.yaml`;
- raw SHA-256:
  `3b61eb5926b5646a12f8767524192cd7ed65a39e27a37aa9672277058489e024`;
- canonical SHA-256:
  `dc4847e125c04b82b3a26154f678d45619f8f7ae8a599aa4865386908ec79e83`;
- cohort: 6 minimal, 7 standard, and 7 full cases;
- held-out requirements are excluded.

The requirements remain explicitly described as internally authored. Reusing
them controls the task while the model and decoding mechanism change; it does
not turn them into an external benchmark.

## 3. Which schema is constrained

The decoding grammar is a case-specific final-artifact JSON Schema compiled by
the V17 schema/compiler path from the same frozen requirement source and a
deterministic requirement-derived design. It must not depend on a model-produced
Round-1 result; otherwise U and G could receive different downstream schemas and
the ablation would be confounded. It is not the AUTOSAR XSD and must never be
described as direct token-level enforcement of ARXML XSD validity.

The exact final-IR schema bytes, compiler identity, prompt bytes, tokenizer, and
chat/completion template must be frozen before qualification. The same schema
text is included in the prompt for all arms; G and A additionally supply those
same schema bytes to vLLM as:

```json
{"structured_outputs":{"json":{}}}
```

where the empty object above is replaced by the frozen schema object. Each
admitted JSON result is passed through the same deterministic JSON-to-ARXML
mapping and the same hash-pinned AUTOSAR 4.2.2 XSD and requirement-obligation
validators. Thus token masking, JSON structure, ARXML XSD validity, and task
obligations remain separate measured layers.

The accepted model-free source export is:

- root:
  `E:\54239\Documents\atlas_vllm_uga_source_assets_v2_2026-08-27`;
- source-manifest content SHA-256:
  `17b03484b99e7e868b16d0450304917449c62355d339968707e01b6e1c4f7c39`;
- offline source/postprocess qualification content SHA-256:
  `2596c9785e5cb540c453b482de5d0e85a055421a3ea610ef13f4b79ecd83d668`;
- qualification result: 20/20 deterministic reference cases passed, with zero
  model calls.

The GPU host records only raw completion, token, audit, latency, and host
metrics evidence. JSON-to-ARXML materialization and the independent validators
run after byte-for-byte transfer on the accepted Windows source tree. This
split prevents the remote host from silently substituting validation code.

If the exact final-IR prompt and schema do not fit the pinned model context, the
qualification fails. The experiment must not silently substitute a dummy,
simplified, unrelated, or legacy GBNF grammar. A reduced-IR study would require a
new protocol version and must be labelled as such.

## 4. Arms

All arms use the same patched vLLM v0.26.0 binary, model revision, tokenizer,
prompt, schema text in the prompt, generation settings, request order, and
case/repetition schedule.

| Arm | Mechanical grammar | Fail-closed audit | Binding observation |
| --- | --- | --- | --- |
| U | off | off | not measured |
| G | XGrammar JSON Schema | off | not measured |
| A | same XGrammar JSON Schema | required | required |

Using the same patched binary in all three arms prevents a stock-versus-patched
version confound. Audit is a fail-closed server capability but is activated by
the request-scoped `structured_outputs.atlas_audit_binding` field only in arm A.
Arm G therefore executes the same grammar on the same continuously running
server without binding classification, hash-chain writes, or audit queue work.
This request-level switch is necessary: a process-wide switch would require
server restarts and confound arm with runtime phase.

The pinned candidate runtime is Qwen3.5-9B at the platform path
`/model/ModelScope/Qwen/Qwen3.5-9B`, served text-only in BF16 with tensor
parallelism 2 on two RTX 4090 GPUs. Qwen thinking is disabled before the request:
the tokenizer chat template is rendered locally with `enable_thinking=False`,
then the exact rendered bytes are sent to raw `/v1/completions` in all arms.
The request explicitly sets `add_special_tokens=false`; the server does not
render a second template or insert a second set of special tokens.

## 5. Binding definition

For constrained decoding step `t`, let `z_t` be the model logits before grammar
masking and let `M_t` be the XGrammar packed mask. The step is binding when:

```text
argmax(z_t) is not allowed by M_t
```

The binding rate is:

```text
number of evaluable constrained steps that are binding
-------------------------------------------------------
number of evaluable constrained steps observed
```

The audit stores the boolean result, request identity, and sample ordinal, not
the pre-mask token ID or token text. `mask_ready` and `binding_step` must form a
one-to-one ordinal mapping for every audited request. Missing, duplicate, or
misaligned observations make the request `INCOMPLETE/NOT_EVALUATED`.

Binding is mechanistic evidence that the grammar intervened. It is not by itself
evidence that the intervention was beneficial. Benefit is assessed only by the
paired U-versus-G structural outcomes.

## 6. Outcomes

### U versus G

- parse success over all scheduled requests;
- final-artifact JSON Schema success, with unparseable outputs recorded as
  `NOT_EVALUATED` for the conditional schema denominator;
- deterministic JSON-to-ARXML mapping success;
- AUTOSAR 4.2.2 XSD success, conditionally over materialized artifacts and
  end-to-end over all scheduled requests;
- end-to-end structural success over all scheduled requests, where an
  unparseable output is a terminal failure;
- frozen requirement-obligation decision;
- output length and termination classification.

This comparison is a controlled same-runtime contrast between mechanical
grammar enforcement and these structural outcomes, within this internally
authored cohort. Its scope and permitted wording are fixed in Section 7.1.

### G versus A

- output hash equality under deterministic decoding;
- parse/schema/obligation decision equality;
- end-to-end request latency, output-token throughput, continuous host/GPU
  utilization samples, trace bytes, queue pressure, and dropped-event count.

This comparison estimates audit-plus-binding instrumentation overhead. It does
not measure human diagnostic utility. The non-streaming raw-completion client
does not claim time-to-first-token or inter-token latency.

### A only

- evaluable constrained steps;
- binding steps;
- binding rate per request and descriptively across cases;
- complete request/grammar/mask/token/end hash-chain verification.

Token steps are not treated as independent statistical units. Binding rates are
descriptive and summarized by case; they do not receive a binomial confidence
interval that assumes token independence.

## 7. Schedule and analysis units

The intended formal schedule is 20 cases x 3 repetitions x 3 arms = 180 local
model requests. Case is the primary analysis unit; repetitions measure runtime
and generation stability. Arm order must be deterministically counterbalanced.
The 60 case-repetition blocks cycle the six U/G/A permutations exactly ten
times each.

The schedule also counterbalances which arm meets the grammar compiler first.
Across the 60 case-repetition blocks, G precedes A in 30 blocks and A precedes
G in 30. Ten cases use G-before-A in one of their three repetitions and ten use
it in two of three; no case uses a single compilation order in all three. An
even split inside a case is arithmetically impossible with three repetitions,
so the property that must hold, and that is tested, is that no case is uniform:
a case that always compiled in the same arm first would be confounded by it.
The 60 case-repetition blocks are descriptive repeated observations, not 60
independent inferential units. U-versus-G inference uses the 20-case unit after
aggregating the three repetitions per case; the paired exact sign test uses
only discordant cases. No V17 Luna output is used as a comparator or training
example.

### 7.1 Pre-declared endpoints and how they may be described

These four commitments are declared here, before the first model request, and
are not to be revised once results exist.

**The primary endpoint is the end-to-end structural decision.** It is the only
*primary* endpoint, and its denominator is the schedule: every non-pass stays
in that denominator, including runs that stopped before a later stage could be
attempted.

**Parse, JSON Schema, materialization, XSD, and selection obligations are
diagnostic secondary endpoints.** Two denominators are in use and must not be
confused:

- *Unconditional.* Parse is attempted for every scheduled request, so parse is
  reported over the schedule, exactly as the primary endpoint is. Sharing a
  denominator does not make it primary.
- *Conditional.* Schema is reported over parse-pass, materialization over
  schema-pass, and XSD and selection obligations each over materialized. XSD
  and selection obligations are siblings, both evaluated on every materialized
  bundle; neither is conditional on the other.

Dividing any of those four conditional counts by the schedule would report
"did not attempt" as "failed", and is not a permitted presentation.

**One significance test is pre-declared, and its aggregation is fixed here.**
The confirmatory test is the paired exact two-sided sign test on U versus G for
the primary endpoint, with the case as the unit. It is computed as follows, and
the procedure may not be varied once results exist:

1. Every case must contribute exactly three repetitions; a case with any other
   count aborts the analysis rather than being aggregated.
2. For each case, count the repetitions in which U reached the primary endpoint
   and, separately, the repetitions in which G did. Each count is an integer in
   0..3.
3. A case is *G-better* if G's count exceeds U's, and *U-better* if U's exceeds
   G's. A case with equal counts is a tie.
4. Ties are excluded from the test and reported separately as the tie count.
5. The statistic is the exact two-sided sign test over the G-better and
   U-better case counts, under the null that a discordant case is equally
   likely to fall either way.

Any other test reported alongside it, including one on parse or schema, is
exploratory and must be labelled as such or carry an explicit multiplicity
correction. The test, its endpoint, its denominator, and the aggregation above
are fixed by this document before any request is issued.

**The comparison is a controlled same-runtime contrast, not an association and
not a cross-model result.** U, G, and A share one model snapshot, one prompt,
one schema, one seed set, one server process, and one postprocessing chain;
only grammar enforcement and audit instrumentation vary. Findings are stated
for this internally authored cohort under that runtime. They are not
generalised to other models, to external AUTOSAR benchmarks, or to any domain
beyond the cohort, and no number here is pooled with or numerically compared
against the V17 Luna study.

## 8. Qualification gate

Before the formal schedule, run a nine-request non-paper qualification on one
predeclared case per tier, with all three arms for each case. It must demonstrate:

1. exact prompt/schema compilation with no fallback;
2. speculative decoding disabled;
3. one binding observation per `mask_ready` ordinal;
4. complete hash chains and zero dropped events;
5. G/A output and posterior-decision equality under deterministic decoding;
6. independent recomputation of binding counts from NDJSON;
7. a fresh output root and an explicit qualification label that prevents these
   requests from entering paper results.

Failure blocks the formal schedule. It is not followed by repeated probing until
the implementation or environment changes and a new qualification identity is
frozen.

The first CUDA qualification identity used a 16,384-token output allowance. It
completed all nine non-paper requests, but the constrained standard and full
cases reached that limit before closing their JSON documents. Their G and A
outputs were byte-identical; the failure therefore did not isolate audit as the
cause. That identity is rejected and cannot enter paper results. The replacement
configuration pins a 65,536-token output allowance: the largest power-of-two
allowance that, together with the observed maximum 55,719-token prompt, remains
below the 131,072-token model context. It requires a new compiled-asset manifest,
schedule, contract, fresh output root, fresh audit root, and a complete repeat of
this nine-request gate. If it also reaches the length limit, formal execution
remains blocked rather than prompting further outcome-driven tuning.

## 9. Runtime launch blockers

The authorized deployment target is Ubuntu 22.04 with two 24 GiB RTX 4090
GPUs, Python 3.12, a 100 GiB instance disk, and a platform-mounted Qwen3.5-9B
model. The system PyTorch/CUDA packages are not part of the experiment. A fresh
`uv` environment must install vLLM 0.26.0 and its pinned PyTorch 2.11 cu130
stack, then apply the hash-checked Python-only overlay. Docker is neither
required nor used.

Admission still requires all of the following on the actual instance:

1. at least 64 GiB host RAM and 16 GiB `/dev/shm`;
2. two visible RTX 4090 devices and a recorded topology;
3. exact overlay verification against the stock vLLM 0.26.0 wheel files;
4. a full model-file hash manifest and a PASS runtime fingerprint;
5. exact tokenizer compilation showing every prompt plus output allowance fits
   the pinned 131072-token context;
6. the nine-request CUDA qualification and independent trace verification.

Qwen's current model documentation recommends recent vLLM support; therefore
model loading and grammar execution under the pinned 0.26.0 runtime are
qualification questions, not assumptions. No model request has been run by
this protocol yet.

## 10. Implementation status on 2026-08-26

The uncommitted qualification patch is in:

`E:\54239\Documents\vllm-upstream-0.26.0`

It currently:

- observes pre-mask argmax in both vLLM V1 and V2 GPU runner paths;
- rejects speculative decoding when binding is required;
- returns only request-keyed binding booleans from worker to EngineCore;
- pairs masks and observations by per-request ordinal;
- records `binding_step` in audit schema v2 and independently verifies the
  one-to-one mapping and aggregate rate;
- treats missing, duplicate, malformed, or pending observations as incomplete.
- exposes audit/binding as an A-only request field while keeping the server
  capability fail-closed, so U/G/A can be counterbalanced without restarts;
- accepts a client-fixed request ID and maps it deterministically to the
  EngineCore audit ID;
- compiles Qwen3.5 prompts locally with thinking disabled and verifies the
  server-returned prompt token IDs against the frozen hash;
- includes deterministic source-schema export, prompt compilation, schedule,
  contract, runtime fingerprint, no-retry runner, and qualification verifier
  tools;
- includes an Ubuntu 22.04, no-Docker deployment path that installs an isolated
  vLLM 0.26.0 cu130 environment and verifies the Python overlay by base hash.

The final local, non-CUDA gates are:

- experiment tooling and infrastructure: all tests pass, zero failures;
- vLLM audit, binding, packed-mask, and verifier logic: all tests pass;
- ATLAS-side binding/popcount behavior: all tests pass;

  This protocol states the requirement, not a count. Test counts change
  whenever a regression test is added, and pinning one here would invalidate
  the protocol hash -- and therefore the bundle and archive identity -- for a
  reason unrelated to the experiment. The counts as executed are recorded in
  the readiness report and re-derivable by running the suites.

  Skipped tests are never counted as passing. The tests that exercise the
  speculative-decoding guards skip on a workstation without a full vLLM
  install; the same two guards are exercised with no skip path by
  `speculative_guard_probe()` in the runtime fingerprint, on the target host,
  where a failure makes the fingerprint `FAIL` and blocks the contract.
- Python AST parsing: every bundled Python file parses;
- vLLM `git diff --check`: passed;
- added vLLM lines longer than 88 characters: zero;
- deployment shell scripts: LF-only;
- source postprocess qualification: 20/20 cases passed with zero model calls.

The deployment bundle manifest records every file hash and rejects missing,
changed, or unexpected files. No CUDA integration result is claimed.

## 11. Identity and execution boundary

Each scheduled request supplies a stable ASCII `request_id`; vLLM returns
`cmpl-<request_id>` and EngineCore audits `cmpl-<request_id>-0`. A-request start
records must also carry the experiment ID, protocol file hash, compiled-asset
manifest content hash, and runtime-fingerprint content hash. Missing or invalid
identity fields prevent the binding-capable server from starting.

The driver runs on the GPU host against `http://127.0.0.1:8000`, uses no proxy,
makes no retries, and stops on either an output-root or control-root
`OPERATOR_STOP` sentinel. Qualification and formal execution require separate
fresh output and audit roots. The formal contract cannot be built without a
PASS qualification manifest and the runner additionally requires an explicit
formal CLI authorization flag.
