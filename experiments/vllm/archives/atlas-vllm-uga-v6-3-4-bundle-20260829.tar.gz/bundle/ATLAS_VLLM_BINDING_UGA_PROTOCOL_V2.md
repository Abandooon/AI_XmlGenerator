# ATLAS vLLM Binding and U/G/A Protocol V2

Date: 2026-08-27 (Asia/Shanghai)

Status: implementation repaired; a fresh non-paper CUDA qualification is required.
No formal or paper-admissible run is authorized by this document.

## 1. Supersession and failed qualification

This protocol supersedes V1 for all future U/G/A work. The completed V2-65536
qualification is permanently rejected. Its immutable evidence root is:

`E:\54239\Documents\atlas_vllm_uga_qualification_v2_65536_20260827_9dcca644`

That run completed 9/9 requests but passed only 2/9 end to end. The standard and
full constrained requests reached 65,536 output tokens. Increasing the limit did
not repair the mechanism and must not be repeated.

Two implementation faults were isolated:

1. qualification predicted the EngineCore trace id, but vLLM appended a random
   internal suffix; and
2. every generated array in the standard/full grammar was unbounded, so valid
   prefixes could continue by repeating array members indefinitely.

The failed root, the prior deployment bundle, and all prior manifests remain
read-only and may not be overwritten or re-labelled.

## 2. Scope and arms

This remains a same-model mechanism microbenchmark over the 20 internally
authored AUTOSAR component requirements. It measures structural outcomes from
grammar enforcement and the cost/binding behavior of audit instrumentation. It
does not establish semantic correctness, external generality, or superiority
over another model or tool.

All arms use the same Qwen3.5-9B snapshot, prompt bytes, execution schema text,
seed, deterministic sampling settings, vLLM process, and posterior validators.

| Arm | XGrammar schema | Fail-closed audit/binding |
| --- | --- | --- |
| U | off | off |
| G | on | off |
| A | on | required |

The formal schedule remains 20 cases x 3 repetitions x 3 arms = 180 requests,
counterbalanced as in V1. It is blocked until a fresh nine-request qualification
passes and the operator separately authorizes formal execution.

## 3. Source schema and execution schema

The source schemas and postprocessing context remain the accepted, model-free V2
source export. A new deterministic transformation produces the schema used in
the prompt, XGrammar, and posterior JSON Schema validation:

1. retain only JSON Schema assertion/applicator keywords;
2. remove XSD provenance and other non-assertion annotation bulk;
3. declare JSON Schema Draft 2020-12;
4. parse exact P-port, R-port, runnable, timing-event, and variable-access counts
   from the deterministic requirement clause and cross-check them against the
   explicit requirement bullets;
5. assign finite `minItems` and `maxItems` to every array; and
6. fail if an array is unknown, unbounded, or the requirement counts disagree.

Top-level P ports, R ports, receiver communication specifications, runnables,
and timing events receive exact bounds. Per-runnable read/write arrays receive
the minimum and maximum declared across that case's runnables; exact posterior
selection obligations continue to enforce runnable-specific membership.

Before tokenizer compilation, every execution schema must pass a model-free
witness matrix containing one accepted instance and rejected witnesses for a
missing required field, wrong type, additional property, too few array items,
and too many array items. The preflight must cover all 20 cases with zero model
requests.

The output allowance returns to 16,384. It may not be raised in response to
another length-capped result. Any such result blocks the formal run and requires
a separately identified protocol change based on a new mechanism diagnosis.

## 4. Stable request identity

The HTTP client supplies a stable `request_id`. For A requests it also supplies:

```json
{
  "structured_outputs": {
    "atlas_audit_binding": true,
    "atlas_audit_request_id": "cmpl-<stable-request-id>-0"
  }
}
```

`atlas_audit_request_id` is required, stable ASCII, request scoped, and forbidden
when audit binding is disabled. EngineCore continues to use its private internal
id, including any random suffix, for in-process trace grouping. The request-start
metadata records the external id, and the independent verifier joins external to
internal identity. Missing, invalid, unexpected, or duplicate external identities
make qualification incomplete. No verifier may predict or normalize an internal
suffix.

## 5. Termination and replay evidence

Every result stores the exact output token-id sequence as canonical JSON,
zlib-compressed and base64 encoded, plus the token count and SHA-256 of the
uncompressed canonical bytes. Qualification independently decodes it and checks
canonicality, count, result hash, usage count, and the A-trace end hash.

For G and A, qualification requires all of the following:

- exactly one JSON value, with only surrounding whitespace;
- Draft 2020-12 execution-schema PASS;
- client finish reason `stop`;
- A-trace engine finish status `FINISHED_STOPPED`;
- A-trace `grammar_terminated=true`; and
- byte-identical G/A output and equal posterior decisions.

The grammar-completion fact is sampled from the request's XGrammar matcher at
request end and is part of the hash-chained audit event. A syntactically closed
prefix is not treated as proof of grammar completion.

## 6. XGrammar matrix

Before CUDA qualification, the 20 compiled execution schemas and their valid and
invalid witnesses are compiled/replayed, without model calls, in isolated
XGrammar 0.2.3, 0.2.4, and 0.2.5 environments using the pinned Qwen tokenizer.
Each version must produce a hash-verified PASS probe, and a collector must reject
missing, duplicate, unexpected, edited, or failed probe records.

The candidate serving runtime remains the separately fingerprinted vLLM 0.26.0
environment. A probe result does not silently change its XGrammar dependency; a
runtime version change requires a new runtime fingerprint, deployment manifest,
contract, and qualification identity.

## 7. Audit and failure handling

A-arm audit is fail closed. For each request the independent verifier requires:

- one start and one end boundary;
- continuous sequence numbers and a valid hash chain;
- one successful grammar compile start/end pair;
- one binding observation for every mask ordinal;
- zero dropped events and no pending observations;
- stable external identity mapped to exactly one internal trace;
- normal stop and terminated grammar; and
- result/audit output-token hash agreement.

The runner and qualification collector write a content-hashed FAIL manifest on
ordinary exceptions. A partially populated directory without a PASS manifest is
never admissible. Qualification, audit, run, postprocess, and formal roots must be
fresh and distinct.

## 8. Fresh qualification gate

The replacement qualification uses the predeclared cases ASW-MIN-04,
ASW-STD-04, and ASW-FULL-03, all three arms, one repetition, and no retries. It
must pass every invariant above, demonstrate at least one evaluable binding step,
and retain all nine requests as non-paper evidence.

Passing qualification permits only construction of a new formal contract. It
does not itself authorize the 180-request formal run. Failure freezes that new
identity and blocks formal execution; it is not repaired by modifying artifacts
inside the failed root.
