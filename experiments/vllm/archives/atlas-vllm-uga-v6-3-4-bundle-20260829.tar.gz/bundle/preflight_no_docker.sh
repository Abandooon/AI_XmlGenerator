#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 3 ]]; then
  echo "usage: $0 TASK_ROOT DEPLOYMENT_BUNDLE_ROOT MODEL_PATH" >&2
  exit 64
fi

task_root="$1"
bundle_root="$2"
model_path="$3"
python_bin="${task_root}/.venv/bin/python"

test -x "${python_bin}"
test -d "${bundle_root}"
test -d "${model_path}"
test -f "${bundle_root}/DEPLOYMENT_BUNDLE_MANIFEST.json"
test -f "${bundle_root}/vllm_overlay/VLLM_OVERLAY_MANIFEST.json"

"${python_bin}" \
  "${bundle_root}/tools/verify_deployment_bundle_v026.py" \
  --bundle-root "${bundle_root}"

os_id="$(. /etc/os-release && printf '%s:%s' "${ID}" "${VERSION_ID}")"
if [[ "${os_id}" != "ubuntu:22.04" ]]; then
  echo "expected ubuntu:22.04, found ${os_id}" >&2
  exit 78
fi

gpu_count="$(nvidia-smi --query-gpu=name --format=csv,noheader | wc -l)"
if [[ "${gpu_count}" -ne 2 ]]; then
  echo "expected two GPUs, found ${gpu_count}" >&2
  exit 78
fi
if nvidia-smi --query-gpu=name --format=csv,noheader | grep -vq 'RTX 4090'; then
  echo "every GPU must be an RTX 4090" >&2
  exit 78
fi

ram_gib="$(awk '/MemTotal/ {print int($2 / 1024 / 1024)}' /proc/meminfo)"
if [[ "${ram_gib}" -lt 64 ]]; then
  echo "at least 64 GiB RAM is required; found ${ram_gib}" >&2
  exit 78
fi
shm_gib="$(df -BG --output=size /dev/shm | tail -n 1 | tr -dc '0-9')"
if [[ "${shm_gib}" -lt 16 ]]; then
  echo "at least 16 GiB /dev/shm is required; found ${shm_gib}" >&2
  exit 78
fi
disk_gib="$(df -BG --output=avail "${task_root}" | tail -n 1 | tr -dc '0-9')"
if [[ "${disk_gib}" -lt 35 ]]; then
  echo "at least 35 GiB free task storage is required; found ${disk_gib}" >&2
  exit 78
fi

"${python_bin}" \
  "${bundle_root}/tools/apply_vllm_overlay_v026.py" \
  --bundle-root "${bundle_root}/vllm_overlay" \
  --verify-only
"${python_bin}" -c \
  'import importlib.metadata as m; assert m.version("vllm") == "0.26.0"; assert m.version("xgrammar") == "0.2.6rc1"; assert m.version("apache-tvm-ffi") == "0.1.10"; assert m.version("transformers") == "5.16.1"; print("structured stack", m.version("vllm"), m.version("xgrammar"), m.version("apache-tvm-ffi"), m.version("transformers"))'
"${python_bin}" -c \
  'import torch; assert torch.cuda.is_available(); assert torch.cuda.device_count() == 2; print([torch.cuda.get_device_name(i) for i in range(2)])'
topology_log="${task_root}/NVIDIA_SMI_TOPOLOGY.txt"
set +e
nvidia-smi topo -m >"${topology_log}" 2>&1
topology_exit="$?"
set -e
cat "${topology_log}"
if [[ "${topology_exit}" -ne 0 ]]; then
  # Some restarts of this managed container expose a cgroup cpuset whose CPU
  # identifiers do not intersect the container's online CPU identifiers.
  # hwloc then cannot render the informational topology matrix even though
  # CUDA sees both devices. Admit only that exact signature; the contract still
  # requires the stronger two-rank NCCL all-reduce gate before model launch.
  if ! grep -Fq 'Topology does not contain any PU' "${topology_log}" \
      || ! grep -Fq 'Failed to run topology matrix' "${topology_log}"; then
    echo "unexpected nvidia-smi topology failure" >&2
    exit 78
  fi
  {
    echo "ATLAS_KNOWN_HWLOC_CPUSET_DEGRADATION"
    grep -E 'Cpus_allowed|Mems_allowed' /proc/self/status
    printf 'cgroup_cpuset_effective='
    cat /sys/fs/cgroup/cpuset.cpus.effective
    printf 'kernel_online_cpus='
    cat /sys/devices/system/cpu/online
  } >>"${topology_log}"
  unique_gpu_uuids="$(
    nvidia-smi --query-gpu=uuid --format=csv,noheader | sort -u | wc -l
  )"
  if [[ "${unique_gpu_uuids}" -ne 2 ]]; then
    echo "expected two distinct GPU UUIDs" >&2
    exit 78
  fi
  echo "PREFLIGHT_TOPOLOGY_DEGRADED_REQUIRES_NCCL_GATE"
fi
echo "PREFLIGHT_PASS"
