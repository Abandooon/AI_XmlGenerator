# V6.3.2 XGrammar regression-identity repair

The two exact token-rejection regressions (`005.json` at token 599 and
`007.json` at token 1214) were collected under the V4 execution schemas. V6.3
intentionally replaced those schemas with a stricter complete final-artifact
contract, so replaying the frozen token sequences against the current schemas
would no longer test the historical XGrammar behavior represented by the
frozen indexes.

V6.3.2 packages the original V4 compiled assets as `005.asset.json` and
`007.asset.json`. The zero-model regression gate verifies the asset content
hash, case identity, and every schema-hash claim in the historical result
before compiling that legacy schema and replaying its token sequence. The
result now records the legacy asset file hash, content hash, and schema hash.
The current 20 V6.3 execution schemas remain subject to their own valid and
adversarial XGrammar replays; they are not weakened or replaced by the legacy
snapshots.

The adversarial-schema walker now traverses both ordinary `items` and
position-specific `prefixItems`. Its over-cardinality mutation preserves the
entire valid prefix and appends exactly one forbidden item, so the failure is
attributable to `maxItems`/`items: false`, not to corrupting an earlier
position. V6.3.4 subsequently corrected the witness separators used by the
expanded regression; see `V6_3_4_XGRAMMAR_WITNESS_SERIALIZATION_REPAIR.md`.

This is a zero-model evidence-identity repair. It does not change the model,
prompts, frozen cases, U/G/A treatment, sampling parameters, AUTOSAR evaluator,
or acceptance criteria.
