# V6.2.1 XGrammar schema-probe repair

The first V6.2 zero-model cloud gate compiled all 20 execution schemas but
incorrectly replayed compact JSON while the pinned `any_whitespace=False`
grammar uses XGrammar's default `", "` and `": "` separators. It also created
the matcher without the production overlay's
`terminate_without_stop_token=True` setting. All valid witnesses therefore
rejected at token index 9. No model request was made.

V6.2.1 changes only `probe_xgrammar_execution_schemas_v030.py`: witness JSON
now uses the same default separators as the existing correctness regression,
and both valid and invalid matchers use the production termination setting.
Source assets, execution-schema compiler, prompts, model settings, vLLM
overlay, sampling, postprocessing, validators, and experiment schedules are
unchanged. The failed a7 probe root remains immutable diagnostic evidence.
