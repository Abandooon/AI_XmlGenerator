#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 2 ]]; then
  echo "usage: $0 TASK_ROOT DEPLOYMENT_BUNDLE_ROOT" >&2
  exit 64
fi

task_root="$1"
bundle_root="$2"
venv_root="${task_root}/.venv"

if [[ ! -d "${bundle_root}" ]]; then
  echo "deployment bundle does not exist: ${bundle_root}" >&2
  exit 66
fi
if ! command -v uv >/dev/null 2>&1; then
  echo "uv is required; install it before running this script" >&2
  exit 69
fi
# --torch-backend is a preview option, and the cu130 value in particular needs
# uv 0.9.4 or newer: "Add CUDA 13.0 support (#16321)", uv changelog 0.9.4,
# 2025-10-17. An older uv either rejects the option outright or rejects the
# cu130 value, and either failure reads like a package problem rather than a
# toolchain one, so it is caught here by name.
#
# The floor is a capability requirement rather than an exact pin. What has to
# be reproducible is the installed package set, and those versions are fixed by
# the install command below and recorded in the runtime fingerprint, which also
# records the exact uv that produced them.
uv_minimum="0.9.4"
uv_version="$(uv --version | awk '{print $2}')"
if [[ "$(printf '%s\n%s\n' "${uv_minimum}" "${uv_version}" \
        | sort -V | head -n 1)" != "${uv_minimum}" ]]; then
  echo "uv ${uv_minimum} or newer is required for --torch-backend=cu130;" \
       "found ${uv_version}" >&2
  exit 69
fi
if ! command -v nvidia-smi >/dev/null 2>&1; then
  echo "nvidia-smi is required" >&2
  exit 69
fi

mkdir -p "${task_root}"
uv venv "${venv_root}" --python 3.12 --seed
"${venv_root}/bin/python" \
  "${bundle_root}/tools/verify_deployment_bundle_v026.py" \
  --bundle-root "${bundle_root}"
uv pip install \
  --python "${venv_root}/bin/python" \
  "vllm==0.26.0" \
  --torch-backend=cu130

# vLLM 0.26.0 resolves XGrammar 0.2.3, whose token matcher accepts the
# frozen v4 invalid Qwen3.5 token sequences.  The 0.2.6rc1 correctness build
# rejects those same sequences at their first schema-invalid property.  Pin
# the exact PyPI-attested CPython 3.12 manylinux x86-64 wheel, including its
# SHA-256, so a different artifact cannot enter this qualification identity.
xgrammar_requirement="xgrammar @ https://files.pythonhosted.org/packages/2e/97/d74d1396f36e7b5843fb2ba4db305ca062f9961a3ddfdfcded6f4c1cc498/xgrammar-0.2.6rc1-cp312-cp312-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl#sha256=97c1f669592a4934ceb51697e26610c110902accfb4078548d5958d82dd341a9"
uv pip install \
  --python "${venv_root}/bin/python" \
  "${xgrammar_requirement}" \
  "apache-tvm-ffi==0.1.10" \
  "transformers==5.16.1"
uv pip check --python "${venv_root}/bin/python"

"${venv_root}/bin/python" \
  "${bundle_root}/tools/apply_vllm_overlay_v026.py" \
  --bundle-root "${bundle_root}/vllm_overlay"
"${venv_root}/bin/python" \
  "${bundle_root}/tools/apply_vllm_overlay_v026.py" \
  --bundle-root "${bundle_root}/vllm_overlay" \
  --verify-only

"${venv_root}/bin/python" -c \
  'import importlib.metadata as m, torch, vllm, xgrammar; assert m.version("vllm") == "0.26.0"; assert m.version("torch").startswith("2.11."); assert str(torch.version.cuda).startswith("13.0"); assert m.version("xgrammar") == "0.2.6rc1"; assert m.version("apache-tvm-ffi") == "0.1.10"; assert m.version("transformers") == "5.16.1"; print(m.version("vllm"), m.version("torch"), torch.version.cuda, m.version("xgrammar"), m.version("apache-tvm-ffi"), m.version("transformers"))'
