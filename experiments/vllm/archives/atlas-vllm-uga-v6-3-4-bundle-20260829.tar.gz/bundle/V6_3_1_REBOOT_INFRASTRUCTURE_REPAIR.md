# V6.3.1 reboot infrastructure-probe repair

After the cloud instance was powered off and restarted, CUDA still exposed two
idle RTX 4090 GPUs, but the managed container reported effective cgroup CPUs
`32-39,48-53,96-103,112-117` while the kernel reported online CPUs `0-27`.
`nvidia-smi topo -m` therefore failed with the exact hwloc signature
`Topology does not contain any PU` / `Failed to run topology matrix`. The a9
preflight failed closed before assets were compiled or any model request.

V6.3.1 records the full topology output plus cpuset evidence. Only that exact
managed-container signature is admitted as a degraded informational topology
probe, and only when two distinct GPU UUIDs remain visible. The experiment
contract still cannot be built unless the stronger direct two-rank NCCL
all-reduce gate passes with both rank records, mean 2.0,
`NCCL_CUMEM_HOST_ENABLE=0`, and no P2P override.

The first post-reboot NCCL diagnostic completed far enough to emit two rank
JSON records concurrently, but their stdout bytes interleaved on one line and
the parent parser raised `JSONDecodeError: Extra data`. V6.3.1 makes each rank
atomically write a separate temporary record file; stdout is retained only as
hashed diagnostics. This changes evidence transport, not the NCCL operation or
acceptance criteria.

No model request was made in a7, a8, or a9. All failed roots remain immutable.
