# V6.3.3 runtime-topology fingerprint repair

After the managed cloud container reboot, shell preflight correctly recorded
and conditionally admitted the exact known `nvidia-smi topo -m` hwloc/cpuset
failure, but the runtime-fingerprint builder still invoked the same command via
`subprocess.check_output`. It therefore aborted on exit status 255 before it
could write a fingerprint, even though no model request had been made and the
mandatory direct NCCL gate had not yet run.

V6.3.3 makes the runtime fingerprint use the same fail-closed rule as shell
preflight. A successful topology matrix is recorded normally. A failed matrix
is admitted only when both exact signatures are present, two distinct GPU UUIDs
are visible, and `/proc/self/status`, the effective cgroup cpuset, and kernel
online-CPU evidence are all available. The complete stdout, stderr, return
code, mode, affinity evidence, and admission errors are stored in the hashed
runtime fingerprint.

The experiment contract independently validates this evidence. Degraded mode
explicitly requires the separate two-rank NCCL gate, which still must report
both ranks, mean 2.0, `NCCL_CUMEM_HOST_ENABLE=0`, and no P2P override. This
repair does not turn topology failure into a CUDA/NCCL success claim; it keeps
the informational topology probe and the functional transport gate distinct.

The a11 root failed before asset compilation and before any model request. It
remains immutable diagnostic evidence.
