# ATLAS vLLM Binding and U/G/A Protocol V5 (V6.2 executable contract)

Date: 2026-08-28 (Asia/Shanghai)

Status: V6.3.4 executable-contract and witness-serialization repair complete. A
fresh CUDA qualification remains mandatory before the formal run. The operator
authorized upload, qualification, repair reruns, and the 180-request formal
experiment on 2026-08-28, conditional on every fail-closed gate passing.

## 1. Supersession and immutable failed evidence

This protocol supersedes V4 for future U/G/A work. It does not overwrite or
relabel any previous deployment, qualification, audit, postprocess, or result
root. In particular, the completed V4 qualification remains failed
infrastructure evidence.

The completed V6.1.1 formal root also remains immutable diagnostic evidence.
Its G/A arms passed JSON parsing and the then-compiled execution schema in all
120 requests, and A recorded 579 binding events over 55,020 audited token
steps. Nevertheless, G/A passed independent AUTOSAR XSD validation in only
84/120 requests and the full end-to-end structural criterion in only 36/120.
The root cause was a compiler defect: it deleted the frozen
`x-atlas-instance-value-constraints` metadata without translating its
anchor-scoped values into standard JSON Schema assertions. Broad component
reference patterns therefore admitted invented path components. This root is
not admissible evidence for a claim that the grammar enforced the complete
case contract; its 579/55,020 binding statistic may be reported only as a
diagnostic of that rejected contract.

V4 completed all 9 requests. The minimal G/A requests succeeded, but the
standard and full G/A requests produced a closed JSON-looking prefix followed
by repeated prose/self-correction until the 16,384-token cap. Exact offline
replay found two independent implementation defects:

1. XGrammar 0.2.3 accepted the entire invalid frozen Qwen3.5 token sequence;
   the pinned XGrammar 0.2.6rc1 correctness build rejects the same sequences at
   token indexes 599 (standard) and 1214 (full).
2. vLLM 0.26.0 did not construct the matcher with
   `terminate_without_stop_token=True` and did not stop a request when the
   matcher reported root-grammar termination.

The V4 offline postprocessor also compared the source-schema hash directly to
the transformed execution-schema hash. V5 validates the complete identity
chain instead: source asset -> compiled source identity -> compiled execution
identity.

The completed V5 qualification also remains immutable failed evidence. Its
nine scheduled requests completed with no retry, and all G/A token streams
were accepted by the finite execution schema. However, vLLM 0.26.0 interpreted
the V5 scheduler's grammar-completion `FINISHED_STOPPED` status as proof that
the last token was an EOS/stop marker. The output processor therefore retained
the final token in token evidence but omitted it from response text. All six
G/A response texts lacked exactly one JSON-closing payload token and failed
independent parsing. V6 carries an explicit grammar-completion stop reason from
the scheduler to the output processor so this payload token is decoded, while
ordinary EOS and configured stop-token exclusion behavior remains unchanged.

The same container exposes invalid NUMA topology to hwloc and provides no
cross-GPU peer access. The default two-rank NCCL path failed when one rank used
cuMem host allocations. A two-rank all-reduce passed with
`NCCL_CUMEM_HOST_ENABLE=0` and without disabling P2P. V6.1 therefore treats
that single environment value as frozen infrastructure configuration, records
it in the runtime fingerprint and contract, and requires a fresh two-rank NCCL
all-reduce gate before contract construction.

## 2. Scope and arms

This is a same-model mechanism microbenchmark over 20 internally authored
AUTOSAR component requirements. It measures structural outcomes from grammar
enforcement and the cost/binding behavior of audit instrumentation. It does not
establish semantic correctness, external generality, or superiority over
another model or tool.

All arms use the same frozen Qwen3.5-9B model tree, prompt bytes, execution
schema, seed, deterministic sampling settings, vLLM process, and posterior
validators.

| Arm | XGrammar execution schema | Fail-closed audit/binding |
| --- | --- | --- |
| U | off | off |
| G | on | off |
| A | on | required |

U is an observational unconstrained baseline. Qualification requires a
complete U result file for each block but does not require U parse or schema
success. G and A must satisfy every strict qualification invariant in Section
6.

The formal schedule remains 20 cases x 3 repetitions x 3 arms = 180 requests.
It is blocked until a fresh nine-request qualification passes. Formal execution
is already authorized under that condition; no second authorization is needed.

## 3. Source and execution schemas

The accepted V2 source export, requirements, postprocess contexts, interfaces,
AUTOSAR XSD, and validation code remain hash-frozen and unchanged. No live
Neo4j query or dynamic schema construction occurs during this experiment. The
V6.2 deterministic execution transformation:

1. retains JSON Schema assertion/applicator keywords;
2. removes XSD provenance and non-assertion annotation bulk;
3. declares JSON Schema Draft 2020-12;
4. cross-checks exact port, runnable, timing-event, and variable-access counts;
5. resolves every frozen instance-value constraint against its ordered anchor
   context and converts it to a standard exact assertion: `const` for 670
   non-numeric values and equal inclusive bounds for 50 numeric values (the
   latter avoids a reproduced XGrammar 0.2.6rc1 numeric-`const` defect);
6. expands each named repeated array into ordered `prefixItems`, one
   context-specialized item schema per frozen identity;
7. promotes every surviving obligation-backed property to `required`, prunes
   branches that are inapplicable to that anchored instance, and assigns equal
   finite `minItems` and `maxItems` to every surviving array; and
8. fails closed on missing, duplicated, unselected, mistyped, unknown,
   unbounded, or cardinality-inconsistent constraints.

Across the 20 frozen cases the transformation must account for exactly 720 of
720 exported instance-value constraints. Together with 34 ordinary source
`const` leaves, the model-free negative matrix mutates 754 exact scalar slots
one at a time and deletes 1,451 required properties one at a time; every
mutation must be rejected. The synthesized valid witness for every case must
then materialize and pass AUTOSAR XSD, task-selection obligations, artifact
profile, reference checks, and the independent evaluator (20/20 each) before
any model request.

The same execution schema bytes are placed in the English prompt for all three
arms, compiled by XGrammar only for G/A, and used for posterior validation for
all arms. U therefore receives the same fully specified task contract but no
token mask. The contract intentionally specifies the complete final artifact
for each benchmark case; this is a structural contract-enforcement experiment,
not a test of open-ended design creativity. The output allowance is 16,384
tokens and may not be raised in response to another length-capped result.

## 4. Prompt output contract

Some frozen requirement text contains the legacy sentence "Return only
complete XML." It is quoted task data, not the active response-format
instruction. The final prompt instruction explicitly supersedes it and orders
one JSON value conforming to the execution schema, with no XML, Markdown,
self-correction, explanation, or second JSON value.

## 5. Structured-output runtime and zero-model gate

The serving stack is pinned to vLLM 0.26.0, Transformers 5.16.1, and XGrammar
0.2.6rc1. The server uses the XGrammar backend with
`disable_any_whitespace=true`. G/A matchers are created with
`terminate_without_stop_token=True`; after accepted tokens complete the root
grammar, the scheduler records `FINISHED_STOPPED`, attaches the explicit
`atlas_structured_output_grammar_terminated` reason, and stops that request.
The output processor treats only that reason as a payload-completing stop and
detokenizes the last accepted token. EOS and configured stop-token paths retain
upstream exclusion semantics.

The launcher must set the contract-pinned
`NCCL_CUMEM_HOST_ENABLE=0`. No `NCCL_P2P_DISABLE` override is permitted. The
server launch log records the effective required-environment map before vLLM
executes.

Before a contract can be built, a zero-model regression gate must pass against
the exact compiled assets and mounted model tokenizer. It must:

- compile all 20 schemas with strict whitespace;
- accept, complete, and terminate a valid witness without EOS;
- reject nested missing-required, additional-property, wrong-type, below-min,
  and above-max witnesses;
- reject a first token appended after a valid root value;
- replay the frozen V4 standard/full failures and reject them exactly at token
  indexes 599 and 1214; and
- replay the two exact final token IDs lost by V5 (92 and 29958) through the
  installed Qwen tokenizer and vLLM incremental detokenizer, require complete
  grammar-stop text, and require unchanged ordinary-stop exclusion behavior;
- execute a two-rank NCCL all-reduce over both visible GPUs with
  `NCCL_CUMEM_HOST_ENABLE=0`, require rank means of 2.0, and reject any P2P
  override; and
- record `model_request_count=0`, package versions, asset identity, and a
  canonical content hash.

Missing, edited, version-mismatched, or failed regression evidence prevents
contract construction. The old version matrix is not a current gate because it did
not replay the actual failing sequences and therefore could not establish the
required correctness property.

## 6. Qualification invariants

The qualification uses ASW-MIN-04, ASW-STD-04, and ASW-FULL-03, all three arms,
one repetition, and no retries. Every scheduled request must have a complete,
hash-bound result. For G and A, qualification additionally requires:

- exactly one JSON value with only allowed surrounding whitespace;
- Draft 2020-12 execution-schema PASS;
- response text contains the grammar-completing payload token represented by
  the final output-token evidence;
- client finish reason `stop`;
- A-trace engine finish status `FINISHED_STOPPED`;
- A-trace `grammar_terminated=true`;
- byte-identical G/A output and equal posterior decisions; and
- at least one evaluable A binding step.

Every result stores canonical, compressed output token-id evidence. The
independent verifier checks its count and hashes and joins the stable external
request identity to exactly one internal trace. For A it also requires one
start/end boundary, continuous sequence numbers, a valid hash chain, successful
grammar compilation, a binding observation for every mask ordinal, zero
dropped or pending observations, and result/audit token-hash agreement.

## 7. Failure and authorization boundary

All roots must be fresh and distinct. An ordinary exception writes a
content-hashed FAIL manifest. A partial directory without a PASS manifest is
never admissible. A failed identity is frozen and is not repaired by editing
artifacts inside that root.

Passing qualification permits only construction of a new formal contract. It
does not authorize the 180-request formal run. Both qualification and formal
model requests require separate, explicit operator instructions.
