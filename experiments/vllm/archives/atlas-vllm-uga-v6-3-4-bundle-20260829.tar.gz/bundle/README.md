# ATLAS vLLM U/G/A V6.3.4 deployment package

V6.2 fixes the V6.1.1 execution-schema completeness defect. The frozen source
assets are unchanged. The compiler now resolves all 720 anchor-scoped instance
value constraints into ordinary typed `const` assertions, expands named arrays
into exact `prefixItems`, and requires every applicable obligation-backed
branch. A model-free materialization gate proves 20/20 AUTOSAR XSD, selection,
artifact-profile, and independent-evaluator success before cloud execution.
V6.2.1 additionally fixes only the zero-model XGrammar schema probe's witness
serialization/termination settings; see `V6_2_1_XGRAMMAR_PROBE_REPAIR.md`.
V6.3 represents the 50 numeric exact values with equal inclusive bounds because
XGrammar 0.2.6rc1 miscompiles non-integral numeric `const`; see
`V6_3_NUMERIC_EXACT_REPAIR.md`.
V6.3.1 records the post-reboot managed-container hwloc/cpuset degradation and
uses atomic per-rank NCCL evidence; see
`V6_3_1_REBOOT_INFRASTRUCTURE_REPAIR.md`.
V6.3.2 binds the two frozen V4 token-level rejection regressions to their
original hash-pinned V4 schemas and makes the current-schema adversarial walker
cover position-specific `prefixItems`; see
`V6_3_2_XGRAMMAR_REGRESSION_IDENTITY_REPAIR.md`.
V6.3.3 applies the same exact managed-container hwloc/cpuset admission rule to
the runtime fingerprint as to shell preflight while preserving the mandatory
two-rank NCCL gate; see `V6_3_3_RUNTIME_TOPOLOGY_FINGERPRINT_REPAIR.md`.
V6.3.4 aligns the expanded current-schema regression witness serialization
with XGrammar 0.2.6rc1's pinned `any_whitespace=False` runtime format; see
`V6_3_4_XGRAMMAR_WITNESS_SERIALIZATION_REPAIR.md`.

This isolated package targets Ubuntu 22.04, Python 3.12, two 24 GiB RTX 4090
GPUs, CUDA-driver compatibility with the cu130 vLLM wheel, at least 64 GiB RAM,
at least 16 GiB `/dev/shm`, and a 100 GiB instance disk. It does not use Docker
or inherit the platform PyTorch environment.

The model is `/model/ModelScope/Qwen/Qwen3.5-9B`. Serving is text-only with
tensor parallelism 2, BF16, a frozen 131072-token context, one active sequence,
no speculative decoding, no prefix caching, and locally rendered non-thinking
prompts sent to raw `/v1/completions` with `add_special_tokens=false`.

This is the V6.2 repair governed by `ATLAS_VLLM_BINDING_UGA_PROTOCOL_V5.md`. It
preserves all earlier bundles and failed evidence. The repair pins the
correctness-tested XGrammar build, terminates at root JSON completion, stops the
vLLM request at grammar termination, resolves the legacy XML/JSON prompt
conflict, fixes the postprocessing source/execution schema identity chain, and
preserves the final grammar-completing payload token in response text, and pins
the validated container-safe two-rank NCCL transport configuration.

U remains the unconstrained observational baseline. G uses the finite execution
schema. A uses the identical schema plus request-scoped audit/binding. Strict
qualification applies to G/A; U must be retained but need not parse or validate.

## 1. Bootstrap and preflight

Upload the complete `bundle` directory without modifying it. Use a fresh task
root on the Ubuntu host:

```bash
export TASK_ROOT=/workspace/atlas-vllm-uga-v6-2
export BUNDLE_ROOT=/workspace/bundle
export MODEL_PATH=/model/ModelScope/Qwen/Qwen3.5-9B
export PY="${TASK_ROOT}/.venv/bin/python"

bash "${BUNDLE_ROOT}/bootstrap_no_docker.sh" \
  "${TASK_ROOT}" "${BUNDLE_ROOT}"
bash "${BUNDLE_ROOT}/preflight_no_docker.sh" \
  "${TASK_ROOT}" "${BUNDLE_ROOT}" "${MODEL_PATH}"
```

Do not bypass a version, GPU, RAM, `/dev/shm`, disk, bundle-hash, or
overlay-hash failure.

## 2. Compile assets and run the zero-model regression gate

```bash
"${PY}" "${BUNDLE_ROOT}/tools/preflight_execution_schemas_v029.py" \
  --source-root "${BUNDLE_ROOT}/source_assets" \
  --output "${TASK_ROOT}/EXECUTION_SCHEMA_PREFLIGHT_V4.json"

"${PY}" "${BUNDLE_ROOT}/tools/build_vllm_runtime_fingerprint_v026.py" \
  --model-path "${MODEL_PATH}" \
  --task-root "${TASK_ROOT}" \
  --overlay-manifest \
    "${BUNDLE_ROOT}/vllm_overlay/VLLM_OVERLAY_MANIFEST.json" \
  --output "${TASK_ROOT}/RUNTIME_FINGERPRINT.json"

"${PY}" "${BUNDLE_ROOT}/tools/compile_qwen35_uga_assets_v029.py" \
  --source-root "${BUNDLE_ROOT}/source_assets" \
  --output-root "${TASK_ROOT}/compiled_assets" \
  --model-path "${MODEL_PATH}" \
  --max-model-len 131072 \
  --max-output-tokens 16384

"${PY}" "${BUNDLE_ROOT}/tools/probe_xgrammar_execution_schemas_v030.py" \
  --compiled-assets \
    "${TASK_ROOT}/compiled_assets/COMPILED_ASSET_MANIFEST.json" \
  --model-path "${MODEL_PATH}" \
  --output "${TASK_ROOT}/XGRAMMAR_SCHEMA_PROBE.json"

"${PY}" "${BUNDLE_ROOT}/tools/probe_xgrammar_regressions_v028.py" \
  --compiled-assets \
    "${TASK_ROOT}/compiled_assets/COMPILED_ASSET_MANIFEST.json" \
  --model-path "${MODEL_PATH}" \
  --fixture-root \
    "${BUNDLE_ROOT}/regression_fixtures/v4_xgrammar_failures" \
  --output "${TASK_ROOT}/XGRAMMAR_REGRESSION.json"

"${PY}" "${BUNDLE_ROOT}/tools/probe_structured_stop_detokenization_v029.py" \
  --model-path "${MODEL_PATH}" \
  --output "${TASK_ROOT}/STRUCTURED_STOP_DETOKENIZATION_REGRESSION.json"

"${PY}" "${BUNDLE_ROOT}/tools/probe_nccl_tp2_v030.py" \
  --output "${TASK_ROOT}/NCCL_TP2_REGRESSION.json"
```

Continue only if all seven summaries report `PASS`, 20 assets were compiled,
all 20 exact execution schemas compile and replay in pinned XGrammar 0.2.6rc1,
the regression has `model_request_count: 0`, and its two exact V4 replays reject
at token indexes 599 and 1214. The detokenization regression must preserve token
IDs 92 and 29958 in grammar-completed text while retaining ordinary-stop token
exclusion. The NCCL gate must show both ranks, mean 2.0,
`NCCL_CUMEM_HOST_ENABLE=0`, and no P2P override. These gates make no model
request.

## 3. Build and dry-run the nine-request qualification

```bash
"${PY}" "${BUNDLE_ROOT}/tools/build_uga_schedule_v031.py" \
  --assets-manifest \
    "${TASK_ROOT}/compiled_assets/COMPILED_ASSET_MANIFEST.json" \
  --kind qualification \
  --experiment-id atlas-vllm-uga-qwen35-qualification-v6-2 \
  --output "${TASK_ROOT}/QUALIFICATION_SCHEDULE.json"

"${PY}" "${BUNDLE_ROOT}/tools/build_uga_contract_v031.py" \
  --protocol "${BUNDLE_ROOT}/ATLAS_VLLM_BINDING_UGA_PROTOCOL_V5.md" \
  --schedule "${TASK_ROOT}/QUALIFICATION_SCHEDULE.json" \
  --assets-manifest \
    "${TASK_ROOT}/compiled_assets/COMPILED_ASSET_MANIFEST.json" \
  --runtime-fingerprint "${TASK_ROOT}/RUNTIME_FINGERPRINT.json" \
  --overlay-manifest \
    "${BUNDLE_ROOT}/vllm_overlay/VLLM_OVERLAY_MANIFEST.json" \
  --execution-schema-preflight \
    "${TASK_ROOT}/EXECUTION_SCHEMA_PREFLIGHT_V4.json" \
  --materialized-witness-preflight \
    "${BUNDLE_ROOT}/MATERIALIZED_WITNESS_PREFLIGHT_V1.json" \
  --xgrammar-schema-probe "${TASK_ROOT}/XGRAMMAR_SCHEMA_PROBE.json" \
  --xgrammar-regression "${TASK_ROOT}/XGRAMMAR_REGRESSION.json" \
  --detokenization-regression \
    "${TASK_ROOT}/STRUCTURED_STOP_DETOKENIZATION_REGRESSION.json" \
  --nccl-regression "${TASK_ROOT}/NCCL_TP2_REGRESSION.json" \
  --output "${TASK_ROOT}/QUALIFICATION_CONTRACT.json"

"${PY}" "${BUNDLE_ROOT}/tools/run_uga_schedule_v031.py" \
  --contract "${TASK_ROOT}/QUALIFICATION_CONTRACT.json" \
  --schedule "${TASK_ROOT}/QUALIFICATION_SCHEDULE.json" \
  --assets-manifest \
    "${TASK_ROOT}/compiled_assets/COMPILED_ASSET_MANIFEST.json" \
  --dry-run
```

The dry run must report `external_model_calls: 0` and `request_count: 9`.

## 4. Run qualification in three terminals

The server binds only to `127.0.0.1:8000`. Use fresh, non-existent or empty
run, audit, control, and postprocess roots.

Terminal 1 — server:

```bash
"${PY}" "${BUNDLE_ROOT}/tools/launch_vllm_qwen35_v026.py" \
  --contract "${TASK_ROOT}/QUALIFICATION_CONTRACT.json" \
  --runtime-fingerprint "${TASK_ROOT}/RUNTIME_FINGERPRINT.json" \
  --overlay-manifest \
    "${BUNDLE_ROOT}/vllm_overlay/VLLM_OVERLAY_MANIFEST.json" \
  --audit-root "${TASK_ROOT}/qualification_audit"
```

Terminal 2 — host metrics:

```bash
"${PY}" "${BUNDLE_ROOT}/tools/monitor_vllm_host_metrics_v026.py" \
  --output "${TASK_ROOT}/qualification_metrics.ndjson" \
  --stop-file "${TASK_ROOT}/qualification_metrics.stop" \
  --interval-seconds 0.25
```

Terminal 3 — wait for `/v1/models`, then run:

```bash
mkdir -p "${TASK_ROOT}/qualification_control"
"${PY}" "${BUNDLE_ROOT}/tools/run_uga_schedule_v031.py" \
  --contract "${TASK_ROOT}/QUALIFICATION_CONTRACT.json" \
  --schedule "${TASK_ROOT}/QUALIFICATION_SCHEDULE.json" \
  --assets-manifest \
    "${TASK_ROOT}/compiled_assets/COMPILED_ASSET_MANIFEST.json" \
  --output-root "${TASK_ROOT}/qualification_run" \
  --control-root "${TASK_ROOT}/qualification_control" \
  --metrics-stop-file "${TASK_ROOT}/qualification_metrics.stop"
```

Creating `OPERATOR_STOP` in `qualification_run` or `qualification_control`
requests cooperative termination. There are no automatic retries. Preserve
every partial root after any failure.

## 5. Transfer and independently verify

Stop the server after the nine requests. Copy the runtime fingerprint, compiled
assets, schedule, contract, run root, audit root, metrics file, and the unchanged
bundle back byte-for-byte.

On the original Windows workstation, use the V6-bundled postprocessor:

```powershell
& 'E:\git projects\AI_XmlGenerator\.venv\Scripts\python.exe' `
  '<TRANSFER_ROOT>\bundle\tools\postprocess_uga_results_v028.py' `
  --contract '<TRANSFER_ROOT>\QUALIFICATION_CONTRACT.json' `
  --schedule '<TRANSFER_ROOT>\QUALIFICATION_SCHEDULE.json' `
  --compiled-assets-manifest `
    '<TRANSFER_ROOT>\compiled_assets\COMPILED_ASSET_MANIFEST.json' `
  --source-root '<TRANSFER_ROOT>\bundle\source_assets' `
  --run-root '<TRANSFER_ROOT>\qualification_run' `
  --output-root '<FRESH_POSTPROCESS_ROOT>'

& 'E:\git projects\AI_XmlGenerator\.venv\Scripts\python.exe' `
  '<TRANSFER_ROOT>\bundle\tools\verify_uga_qualification_v031.py' `
  --contract '<TRANSFER_ROOT>\QUALIFICATION_CONTRACT.json' `
  --schedule '<TRANSFER_ROOT>\QUALIFICATION_SCHEDULE.json' `
  --run-root '<TRANSFER_ROOT>\qualification_run' `
  --audit-root '<TRANSFER_ROOT>\qualification_audit' `
  --postprocess-root '<FRESH_POSTPROCESS_ROOT>' `
  --audit-verifier `
    '<TRANSFER_ROOT>\bundle\vllm_overlay\overlay\vllm\v1\structured_output\audit.py' `
  --output '<TRANSFER_ROOT>\QUALIFICATION_RESULT.json'
```

The verifier requires strict G/A success and equivalence, stable request/audit
identity, replayable token evidence, complete audit hash chains, and at least
one evaluable binding step. A FAIL result or missing PASS result blocks formal
execution.

## Authorization boundary

The operator authorized upload, qualification, repair reruns, and the formal
180-request run on 2026-08-28. Qualification PASS is still a mandatory technical
gate. After it passes, build the formal contract from that exact qualification
identity and use the explicit `--authorize-formal` command-line flag; no further
interactive authorization is required.
