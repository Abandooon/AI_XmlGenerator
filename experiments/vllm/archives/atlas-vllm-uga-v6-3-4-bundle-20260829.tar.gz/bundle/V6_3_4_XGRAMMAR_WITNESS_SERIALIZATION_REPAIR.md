# V6.3.4 XGrammar witness-serialization repair

The independent V6.3 schema probe passed all 20 current schemas under the
pinned cloud runtime, but the expanded regression probe rejected every valid
witness at token index 9. The two legacy V4 token/schema pairs still passed at
their exact expected indexes 599 and 1214.

The uniform index-9 failure isolated the cause to witness serialization. The
regression probe had been changed to compact separators, while XGrammar
0.2.6rc1 with the server's frozen `any_whitespace=False` setting expected the
same default JSON object separators used by the already-passing schema probe
and runtime path. V6.3.4 restores those separators while keeping sorted keys,
so instance property order remains aligned with the sorted schema supplied to
the compiler. This behavior is also checked directly on the pinned cloud
runtime rather than inferred from a later XGrammar release.

This repair does not change a schema, exact value, prompt, model parameter,
arm, evaluator, or acceptance rule. The a12 root contains zero model requests
and remains immutable diagnostic evidence.
