# V6.3 numeric exact-assertion repair

The corrected V6.2.1 schema probe accepted the three string-only minimal cases
but rejected the remaining valid witnesses at the last token of the first
non-integral numeric `const` (for example `ALIVE-TIMEOUT: 0.3`). A minimal
XGrammar 0.2.6rc1 reproduction accepted the token sequence for an unconstrained
number and for equal inclusive bounds, but rejected the same value under
numeric `const` or `enum`. No model request was made in a7 or a8.

V6.3 compiles the 50 frozen numeric exact values as semantically equivalent
Draft 2020-12 `minimum == maximum` assertions. The remaining 670 exported exact
values use `const`; 34 ordinary source const leaves are retained. An in-memory
cloud replay proved all 20 valid witnesses are accepted and terminate under
the production XGrammar settings before this bundle was built. The exhaustive
posterior negative matrix still mutates all 754 exact scalar slots and requires
rejection.

Source assets, requirements, prompts apart from their deterministically
compiled schema text, vLLM overlay, sampling, postprocessing, validators, and
schedule design are unchanged.
