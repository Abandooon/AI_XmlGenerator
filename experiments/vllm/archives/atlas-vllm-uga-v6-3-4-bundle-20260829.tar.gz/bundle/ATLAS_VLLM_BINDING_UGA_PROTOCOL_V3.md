# ATLAS vLLM Binding and U/G/A Protocol V3

Date: 2026-08-28 (Asia/Shanghai)

Status: V5 mechanism repair complete locally; one fresh, non-paper CUDA
qualification remains required. This document does not authorize GPU model
requests or the formal experiment.

## 1. Supersession and immutable failed evidence

This protocol supersedes V2 for future U/G/A work. It does not overwrite or
relabel any previous deployment, qualification, audit, postprocess, or result
root. In particular, the completed V4 qualification remains failed
infrastructure evidence.

V4 completed all 9 requests. The minimal G/A requests succeeded, but the
standard and full G/A requests produced a closed JSON-looking prefix followed
by repeated prose/self-correction until the 16,384-token cap. Exact offline
replay found two independent implementation defects:

1. XGrammar 0.2.3 accepted the entire invalid frozen Qwen3.5 token sequence;
   the pinned XGrammar 0.2.6rc1 correctness build rejects the same sequences at
   token indexes 599 (standard) and 1214 (full).
2. vLLM 0.26.0 did not construct the matcher with
   `terminate_without_stop_token=True` and did not stop a request when the
   matcher reported root-grammar termination.

The V4 offline postprocessor also compared the source-schema hash directly to
the transformed execution-schema hash. V5 validates the complete identity
chain instead: source asset -> compiled source identity -> compiled execution
identity.

## 2. Scope and arms

This is a same-model mechanism microbenchmark over 20 internally authored
AUTOSAR component requirements. It measures structural outcomes from grammar
enforcement and the cost/binding behavior of audit instrumentation. It does not
establish semantic correctness, external generality, or superiority over
another model or tool.

All arms use the same frozen Qwen3.5-9B model tree, prompt bytes, execution
schema, seed, deterministic sampling settings, vLLM process, and posterior
validators.

| Arm | XGrammar execution schema | Fail-closed audit/binding |
| --- | --- | --- |
| U | off | off |
| G | on | off |
| A | on | required |

U is an observational unconstrained baseline. Qualification requires a
complete U result file for each block but does not require U parse or schema
success. G and A must satisfy every strict qualification invariant in Section
6.

The formal schedule remains 20 cases x 3 repetitions x 3 arms = 180 requests.
It is blocked until a fresh nine-request qualification passes and the operator
separately authorizes formal execution.

## 3. Source and execution schemas

The accepted V2 source export remains unchanged. The deterministic execution
transformation:

1. retains JSON Schema assertion/applicator keywords;
2. removes XSD provenance and non-assertion annotation bulk;
3. declares JSON Schema Draft 2020-12;
4. cross-checks exact port, runnable, timing-event, and variable-access counts;
5. assigns finite `minItems` and `maxItems` to every array; and
6. fails closed on unknown, unbounded, or inconsistent cardinality.

The same execution schema bytes are placed in the prompt, compiled by
XGrammar, and used for posterior validation. The output allowance is 16,384
tokens and may not be raised in response to another length-capped result.

## 4. Prompt output contract

Some frozen requirement text contains the legacy sentence "Return only
complete XML." It is quoted task data, not the active response-format
instruction. The final prompt instruction explicitly supersedes it and orders
one JSON value conforming to the execution schema, with no XML, Markdown,
self-correction, explanation, or second JSON value.

## 5. Structured-output runtime and zero-model gate

The serving stack is pinned to vLLM 0.26.0, Transformers 5.16.1, and XGrammar
0.2.6rc1. The server uses the XGrammar backend with
`disable_any_whitespace=true`. G/A matchers are created with
`terminate_without_stop_token=True`; after accepted tokens complete the root
grammar, the scheduler records `FINISHED_STOPPED` and stops that request.

Before a contract can be built, a zero-model regression gate must pass against
the exact compiled assets and mounted model tokenizer. It must:

- compile all 20 schemas with strict whitespace;
- accept, complete, and terminate a valid witness without EOS;
- reject nested missing-required, additional-property, wrong-type, below-min,
  and above-max witnesses;
- reject a first token appended after a valid root value;
- replay the frozen V4 standard/full failures and reject them exactly at token
  indexes 599 and 1214; and
- record `model_request_count=0`, package versions, asset identity, and a
  canonical content hash.

Missing, edited, version-mismatched, or failed regression evidence prevents
contract construction. The old version matrix is not a V5 gate because it did
not replay the actual failing sequences and therefore could not establish the
required correctness property.

## 6. Qualification invariants

The qualification uses ASW-MIN-04, ASW-STD-04, and ASW-FULL-03, all three arms,
one repetition, and no retries. Every scheduled request must have a complete,
hash-bound result. For G and A, qualification additionally requires:

- exactly one JSON value with only allowed surrounding whitespace;
- Draft 2020-12 execution-schema PASS;
- client finish reason `stop`;
- A-trace engine finish status `FINISHED_STOPPED`;
- A-trace `grammar_terminated=true`;
- byte-identical G/A output and equal posterior decisions; and
- at least one evaluable A binding step.

Every result stores canonical, compressed output token-id evidence. The
independent verifier checks its count and hashes and joins the stable external
request identity to exactly one internal trace. For A it also requires one
start/end boundary, continuous sequence numbers, a valid hash chain, successful
grammar compilation, a binding observation for every mask ordinal, zero
dropped or pending observations, and result/audit token-hash agreement.

## 7. Failure and authorization boundary

All roots must be fresh and distinct. An ordinary exception writes a
content-hashed FAIL manifest. A partial directory without a PASS manifest is
never admissible. A failed identity is frozen and is not repaired by editing
artifacts inside that root.

Passing qualification permits only construction of a new formal contract. It
does not authorize the 180-request formal run. Both qualification and formal
model requests require separate, explicit operator instructions.
