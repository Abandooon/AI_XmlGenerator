# V6.1.1 qualification verifier repair

Date: 2026-08-28

The V6.1 qualification verifier validated the registered run and postprocess
file sets, then attempted to serialize undefined `result_files` and
`postprocess_files` local variables. This raised `NameError` before verification
could complete. The failure did not change or invalidate the frozen model-run,
audit, or postprocess evidence.

V6.1.1 constructs both lists deterministically from the already validated
manifest registries and records the verifier's own SHA-256 in the qualification
result. A regression test asserts these inventories remain present. No runtime
overlay, prompt, Schema, model, sampling parameter, audit rule, qualification
invariant, or formal authorization rule changed.
